根据 `rl.tex` 与 `manuscriptmain.tex` 整理的“代码与结果图表”最小集合：

1) code/R/
- ldaf_common.R
- 01_expr_filtered.R
- 02_pca_variance_and_scores.R
- 03_disease_axis_from_pca_scores.R
- 04_paired_response_and_tests.R
- 05_figures_make.R
- 06_hvg_sensitivity_disease_axis.R
- 07_higher_k_sensitivity_disease_axis.R
- 08_loo_robustness_disease_axis.R
- 09_wgcna_enrichment.R
- 10_funclu_go_annotation.R

2) figures/
- Fig1_mechanism_latent_space.jpg
- Fig2_disease_axis_and_paired.png
- Fig3_PCA_and_treatment_vectors.png
- Fig4_module_eigengene_heatmap.png
- Fig5_enrichment_ME2_ME16.png

3) results/
- pca_variance_pc1_pc10.csv
- hvg_sensitivity_summary.csv
- higher_k_sensitivity_summary.csv
- paired_response_summary.csv
- module_gene_assignment.csv
