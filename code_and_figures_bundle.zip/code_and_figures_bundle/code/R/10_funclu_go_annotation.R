#!/usr/bin/env Rscript
# GO post hoc annotation for funclu modules (cluster_M*_cond*.csv).
# - Ontologies: BP / CC / MF.
# - Module level: 4x4 panel per ontology (single cond).
# - Row (type) level: one panel per type per ontology (genes = union of that row's modules).
# Outputs: figures under funclu/figs/ and enrichment CSVs under funclu/go_*.

rm(list = ls())

ca <- commandArgs(trailingOnly = FALSE)
ff <- grep("^--file=", ca, value = TRUE)
rdir <- if (length(ff)) dirname(normalizePath(sub("^--file=", "", ff[1]))) else normalizePath(file.path(getwd(), "R"))
source(file.path(rdir, "ldaf_common.R"))

proj_funclu <- proj_path("funclu")
out_figs <- file.path(proj_funclu, "figs")
out_go <- file.path(proj_funclu, "go_all")
dir.create(out_figs, showWarnings = FALSE, recursive = TRUE)
dir.create(out_go, showWarnings = FALSE, recursive = TRUE)

# Layout mirrors Python notebook's module_rows/type_rows.
type_rows <- c("type1", "tpye2", "type3", "type4")
module_rows <- list(
  c(3, 9, 36, 34),
  c(5, 40, 43, 54),
  c(17, 21, 41, 55),
  c(18, 37, 50, 56)
)

cond_list <- NA_integer_

ont_list <- c("BP", "CC", "MF")

top_n <- 8L
pvalueCutoff <- 0.05
qvalueCutoff <- 0.2
relax_pvalueCutoff <- 1.0
relax_qvalueCutoff <- 1.0
min_genes <- 10L

# Figure style for publication-like consistency.
panel_base_size <- 9
panel_title_size <- 9
panel_y_text_size <- 7.5
composite_title_size <- 16

# Parse simple args: --top_n=8, --pvalue=0.05, --qvalue=0.2
get_arg_num <- function(flag, default) {
  m <- grep(paste0("^", flag, "=|^--", flag, " "), ca, value = TRUE)
  if (!length(m)) return(default)
  s <- sub(paste0("^--?", flag, "="), "", m[1])
  as.numeric(s)
}
if ("--top_n" %in% gsub("^--", "", ca)) {
  # not robust; kept for compatibility
}
tn <- get_arg_num("top_n", NA_real_)
if (is.finite(tn)) top_n <- as.integer(tn)
pv <- get_arg_num("pvalue", NA_real_)
if (is.finite(pv)) pvalueCutoff <- pv
qv <- get_arg_num("qvalue", NA_real_)
if (is.finite(qv)) qvalueCutoff <- qv

cond_arg <- get_arg_num("cond", NA_real_)
if (is.finite(cond_arg)) {
  cond_list <- as.integer(cond_arg)
} else {
  # 默认只跑 cond1
  cond_list <- 1L
}


req <- c("clusterProfiler", "org.Hs.eg.db", "ggplot2")
miss <- req[!vapply(req, requireNamespace, logical(1), quietly = TRUE)]
if (length(miss)) {
  stop(
    "缺少包: ", paste(miss, collapse = ", "),
    "\n安装: BiocManager::install(c(\"clusterProfiler\",\"org.Hs.eg.db\")); install.packages(\"ggplot2\")"
  )
}

suppressPackageStartupMessages({
  library(clusterProfiler)
  library(org.Hs.eg.db)
  library(ggplot2)
})

patchwork_ok <- requireNamespace("patchwork", quietly = TRUE)
if (patchwork_ok) suppressPackageStartupMessages(library(patchwork))

message("Reading funclu cluster gene universes ...")
cluster_files <- list.files(
  proj_funclu,
  pattern = "^cluster_M[0-9]+_cond[0-9]+\\.csv$",
  recursive = TRUE,
  full.names = TRUE
)
if (!length(cluster_files)) stop("未找到 funclu cluster_M*_cond*.csv 文件。")

read_genes_from_cluster <- function(f) {
  df <- read.csv(f, check.names = FALSE, stringsAsFactors = FALSE)
  # First column is the "index" in Python (index_col=0); gene IDs are the remaining columns.
  cn <- colnames(df)
  if (length(cn) <= 1L) return(character(0))
  unique(cn[-1L])
}

genes_universe <- unique(unlist(lapply(cluster_files, read_genes_from_cluster), use.names = FALSE))
genes_universe <- genes_universe[!is.na(genes_universe) & nzchar(genes_universe)]
if (length(genes_universe) < 10L) stop("基因 universe 太小，检查 funclu cluster CSV 结构。")
message("universe genes: ", length(genes_universe))

parse_gene_ratio_num <- function(gene_ratio_str) {
  # gene_ratio_str looks like "12/345"
  sapply(gene_ratio_str, function(x) {
    sp <- strsplit(x, "/", fixed = TRUE)[[1]]
    if (length(sp) != 2L) return(NA_real_)
    num <- as.numeric(sp[1])
    den <- as.numeric(sp[2])
    if (!is.finite(num) || !is.finite(den) || den <= 0) return(NA_real_)
    num / den
  })
}

shorten_term_label <- function(x, max_chars = 42L) {
  x <- as.character(x)
  needs_cut <- nchar(x, type = "width", allowNA = TRUE, keepNA = FALSE) > max_chars
  x[needs_cut] <- paste0(substr(x[needs_cut], 1L, max_chars - 1L), "…")
  x
}

make_enrich_for_genes <- function(genes_mod, label, cond_id, ont) {
  genes_mod <- unique(genes_mod[!is.na(genes_mod) & nzchar(genes_mod)])
  if (length(genes_mod) < min_genes) return(list(res = NULL, plot = NULL))

  enrich_attempt <- function(pcut, qcut) {
    tryCatch(
      enrichGO(
        gene = genes_mod,
        OrgDb = org.Hs.eg.db,
        keyType = "ENSEMBL",
        ont = ont,
        universe = genes_universe,
        pAdjustMethod = "BH",
        pvalueCutoff = pcut,
        qvalueCutoff = qcut,
        readable = TRUE
      ),
      error = function(e) NULL
    )
  }

  ego <- enrich_attempt(pvalueCutoff, qvalueCutoff)
  used_relaxed <- FALSE
  if (is.null(ego) || nrow(as.data.frame(ego)) == 0L) {
    ego <- enrich_attempt(relax_pvalueCutoff, relax_qvalueCutoff)
    used_relaxed <- TRUE
  }
  if (is.null(ego) || nrow(as.data.frame(ego)) == 0L) return(list(res = NULL, plot = NULL))

  res <- as.data.frame(ego)
  res$gene_ratio_num <- parse_gene_ratio_num(res$GeneRatio)
  res_top <- res[order(res$p.adjust, res$pvalue), , drop = FALSE]
  res_top <- head(res_top, top_n)

  res_csv_path <- file.path(out_go, sprintf("GO_%s_%s_cond%d.csv", ont, label, cond_id))
  write.csv(res, res_csv_path, row.names = FALSE)

  res_top$term_lab <- as.character(res_top$Description)
  res_top$term_lab <- gsub("^GO:\\s+", "", res_top$term_lab)
  res_top$term_lab <- shorten_term_label(res_top$term_lab, max_chars = 42L)

  p_title <- sprintf("%s (%s)", label, ont)
  if (used_relaxed) p_title <- paste0(p_title, "\n(relaxed)")

  p <- ggplot(res_top, aes(x = gene_ratio_num, y = reorder(term_lab, gene_ratio_num))) +
    geom_point(aes(size = Count, colour = p.adjust), alpha = 0.95) +
    scale_colour_gradient(low = "#D73027", high = "#4575B4", trans = "reverse") +
    scale_size(range = c(3.5, 12)) +
    scale_x_continuous(expand = ggplot2::expansion(mult = c(0.02, 0.22))) +
    coord_cartesian(clip = "off") +
    labs(x = NULL, y = NULL) +
    ggtitle(p_title) +
    theme_minimal(base_size = panel_base_size) +
    theme(
      axis.text.x = element_blank(),
      axis.ticks.x = element_blank(),
      legend.position = "none",
      plot.title = element_text(size = panel_title_size, face = "bold", hjust = 0.5),
      axis.text.y = element_text(size = panel_y_text_size),
      panel.border = element_rect(color = "black", fill = NA, linewidth = 0.5),
      plot.margin = margin(t = 5.5, r = 28, b = 5.5, l = 5.5, unit = "pt")
    )

  list(res = res, plot = p)
}

read_genes_for_cell <- function(type_name, module_id, cond_id) {
  f <- file.path(
    proj_funclu, type_name,
    sprintf("cluster_M%d_cond%d.csv", module_id, cond_id)
  )
  if (!file.exists(f)) return(character(0))
  df <- read.csv(f, check.names = FALSE, stringsAsFactors = FALSE)
  cn <- colnames(df)
  if (length(cn) <= 1L) return(character(0))
  unique(cn[-1L])
}

enrich_one_module <- function(type_name, module_id, cond_id, ont) {
  genes_mod <- read_genes_for_cell(type_name, module_id, cond_id)
  if (!length(genes_mod)) return(list(res = NULL, plot = NULL))
  label <- sprintf("%s_M%d", type_name, module_id)
  make_enrich_for_genes(genes_mod, label, cond_id, ont)
}

cond_plot_one <- function(cond_id, ont) {
  plot_list <- list()
  k <- 0L
  for (r in seq_along(type_rows)) {
    type_name <- type_rows[[r]]
    for (c in seq_along(module_rows[[r]])) {
      module_id <- module_rows[[r]][[c]]
      k <- k + 1L
      message("GO ", ont, ": cond", cond_id, " ", type_name, " M", module_id)
      out <- enrich_one_module(type_name, module_id, cond_id, ont)
      if (is.null(out$res) || is.null(out$plot)) {
        plot_list[[k]] <- ggplot(data.frame(x = 0, y = 0), aes(x = x, y = y)) +
          geom_blank() +
          ggtitle(sprintf("M%d\n(no hits)", module_id)) +
          theme_void() +
          theme(plot.title = element_text(size = 9, face = "bold", hjust = 0.5))
      } else {
        plot_list[[k]] <- out$plot
      }
    }
  }

  if (patchwork_ok) {
    p_grid <- patchwork::wrap_plots(plot_list, ncol = 4, nrow = 4)
    p_grid <- p_grid + patchwork::plot_annotation(
      title = paste0("funclu GO ", ont, " (cond", cond_id, ")"),
      theme = ggplot2::theme(
        plot.title = element_text(size = composite_title_size, face = "bold", hjust = 0.5)
      )
    )
    return(p_grid)
  }

  # Fallback: if patchwork missing, just return the first plot (still saves CSVs).
  return(plot_list[[1]])
}

row_enrich_all <- function(cond_id, ont) {
  for (r in seq_along(type_rows)) {
    type_name <- type_rows[[r]]
    mods <- module_rows[[r]]
    genes_row <- unique(unlist(lapply(mods, function(m) read_genes_for_cell(type_name, m, cond_id)), use.names = FALSE))
    if (!length(genes_row)) next
    message("Row-level GO ", ont, ": cond", cond_id, " ", type_name)
    label <- sprintf("%s_row", type_name)
    out <- make_enrich_for_genes(genes_row, label, cond_id, ont)
    if (is.null(out$res) || is.null(out$plot)) next
    f_png <- file.path(out_figs, sprintf("GO_%s_funclu_%s_cond%d.png", ont, type_name, cond_id))
    f_pdf <- file.path(out_figs, sprintf("GO_%s_funclu_%s_cond%d.pdf", ont, type_name, cond_id))
    ggplot2::ggsave(f_png, out$plot, width = 6, height = 4.5, dpi = 300)
    ggplot2::ggsave(f_pdf, out$plot, width = 6, height = 4.5)
  }
}

for (cond_id in cond_list) {
  for (ont in ont_list) {
    message("Compositing module-level figure for cond ", cond_id, " ontology ", ont)
    p_grid <- cond_plot_one(cond_id, ont)
    f_pdf <- file.path(out_figs, sprintf("GO_%s_funclu_cond%d.pdf", ont, cond_id))
    ggplot2::ggsave(f_pdf, p_grid, width = 20, height = 14)
  }
}

message("All done. Outputs under funclu/figs and funclu/go_all/")

