rm(list = ls())

ca <- commandArgs(trailingOnly = FALSE)
ff <- grep("^--file=", ca, value = TRUE)
rdir <- if (length(ff)) dirname(normalizePath(sub("^--file=", "", ff[1]))) else normalizePath(file.path(getwd(), "R"))
source(file.path(rdir, "ldaf_common.R"))

input_csv <- proj_path("results", "01_expr_filtered.csv")
output_dir <- proj_path("results", "hvg_sensitivity")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

hvg_list <- c(1000, 2000, 3000)

expr_tbl <- read.csv(input_csv, check.names = FALSE, stringsAsFactors = FALSE)
prep <- prepare_fpkm_and_z_log2(expr_tbl)
Z_log2 <- prep$Z_log2
sample_names <- prep$sample_names
sample_group <- prep$sample_group

summary_list <- list()
pair_list <- list()

for (n_hvg in hvg_list) {
  ph <- pca_top_hvg(Z_log2, n_hvg)
  pca_result <- ph$pca_result
  take <- ph$take

  var_prop <- summary(pca_result)$importance[2, ]
  cum_prop <- summary(pca_result)$importance[3, ]

  scores_tbl <- scores_pc12_dataframe(pca_result, sample_names, sample_group)
  scores_tbl <- append_prefix_id(scores_tbl)

  axis <- disease_axis_scores_2d(scores_tbl)
  scores_tbl$score_raw <- axis$score_raw
  scores_tbl$score_z <- axis$score_z
  v <- axis$v

  group_mean <- tapply(scores_tbl$score_raw, scores_tbl$group, mean)
  mean_HC <- unname(group_mean["HC"])
  mean_SLE <- unname(group_mean["SLE"])
  mean_SLET <- unname(group_mean["SLET"])
  ordering_ok <- isTRUE(mean_HC < mean_SLET && mean_SLET < mean_SLE)

  pair_tbl <- paired_response_table(scores_tbl, v)
  pair_tbl$n_hvg <- take

  n_pairs <- nrow(pair_tbl)
  n_toward_health <- sum(pair_tbl$delta_s_raw < 0, na.rm = TRUE)

  write.csv(
    scores_tbl,
    file.path(output_dir, paste0("disease_axis_scores_hvg", take, ".csv")),
    row.names = FALSE
  )

  write.csv(
    pair_tbl,
    file.path(output_dir, paste0("paired_response_summary_hvg", take, ".csv")),
    row.names = FALSE
  )

  pca_var_tbl <- data.frame(
    PC = paste0("PC", seq_along(var_prop)),
    variance_explained = as.numeric(var_prop),
    cumulative_variance = as.numeric(cum_prop),
    variance_explained_pct = round(100 * as.numeric(var_prop), 2),
    cumulative_variance_pct = round(100 * as.numeric(cum_prop), 2),
    n_hvg = take,
    stringsAsFactors = FALSE
  )

  write.csv(
    head(pca_var_tbl, 10),
    file.path(output_dir, paste0("pca_variance_pc1_pc10_hvg", take, ".csv")),
    row.names = FALSE
  )

  summary_list[[as.character(take)]] <- data.frame(
    n_hvg = take,
    PC1_pct = round(100 * var_prop[1], 2),
    PC2_pct = round(100 * var_prop[2], 2),
    PC1_PC2_cumulative_pct = round(100 * cum_prop[2], 2),
    mean_score_HC = mean_HC,
    mean_score_SLET = mean_SLET,
    mean_score_SLE = mean_SLE,
    ordering_HC_lt_SLET_lt_SLE = ordering_ok,
    n_pairs = n_pairs,
    n_toward_health = n_toward_health,
    prop_toward_health = round(n_toward_health / n_pairs, 3),
    stringsAsFactors = FALSE
  )

  pair_list[[as.character(take)]] <- pair_tbl[, c(
    "n_hvg", "pair_id", "pre_sample", "post_sample",
    "delta_s_raw", "vector_length", "cos_theta", "direction_label"
  )]
}

hvg_sensitivity_summary <- do.call(rbind, summary_list)
hvg_sensitivity_pairs <- do.call(rbind, pair_list)

write.csv(
  hvg_sensitivity_summary,
  file.path(output_dir, "hvg_sensitivity_summary.csv"),
  row.names = FALSE
)

write.csv(
  hvg_sensitivity_pairs,
  file.path(output_dir, "hvg_sensitivity_pairs.csv"),
  row.names = FALSE
)

cat("\n=== HVG sensitivity summary ===\n")
print(hvg_sensitivity_summary, row.names = FALSE)

cat("\n=== Paired movement summary by HVG setting ===\n")
print(
  aggregate(
    list(n_toward_health = hvg_sensitivity_pairs$direction_label == "toward_health"),
    by = list(n_hvg = hvg_sensitivity_pairs$n_hvg),
    FUN = sum
  ),
  row.names = FALSE
)

message("\n已写入目录：", output_dir)
message("主要汇总文件：")
message("1) hvg_sensitivity_summary.csv")
message("2) hvg_sensitivity_pairs.csv")
message("以及各 HVG 配置下的明细结果文件")
