rm(list = ls())

ca <- commandArgs(trailingOnly = FALSE)
ff <- grep("^--file=", ca, value = TRUE)
rdir <- if (length(ff)) dirname(normalizePath(sub("^--file=", "", ff[1]))) else normalizePath(file.path(getwd(), "R"))
source(file.path(rdir, "ldaf_common.R"))

input_csv_path <- proj_path("data", "raw", "SLE FPKM data.csv")
results_dir <- proj_path("results")


# 列结构：gene_id, gene_name, gene_locus | 其余列为样本 FPKM
gene_df <- read.csv(input_csv_path, check.names = FALSE)
gene_expr_df <- gene_df[, 4:ncol(gene_df), drop = FALSE]
gene_expr_df[] <- lapply(gene_expr_df, as.numeric)
expr_matrix <- as.matrix(gene_expr_df)

# 只过滤基因：至少 3 个样本中 FPKM > 1
gene_pass_filter <- rowSums(expr_matrix > 1) >= 4
expr_filtered <- cbind(
  gene_df[gene_pass_filter, 1:3, drop = FALSE],
  expr_matrix[gene_pass_filter, , drop = FALSE]
)

cat(sprintf("基因 %d → %d（样本 %d 列）\n", nrow(gene_df), nrow(expr_filtered), ncol(expr_matrix)))
write.csv(expr_filtered, file.path(results_dir, "01_expr_filtered.csv"), row.names = FALSE)
