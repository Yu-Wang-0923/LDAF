rm(list = ls())

ca <- commandArgs(trailingOnly = FALSE)
ff <- grep("^--file=", ca, value = TRUE)
rdir <- if (length(ff)) dirname(normalizePath(sub("^--file=", "", ff[1]))) else normalizePath(file.path(getwd(), "R"))
source(file.path(rdir, "ldaf_common.R"))

input_csv <- proj_path("results", "01_expr_filtered.csv")
output_dir <- proj_path("results", "loo_robustness")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

n_hvg <- 2000L

expr_tbl <- read.csv(input_csv, check.names = FALSE, stringsAsFactors = FALSE)
prep <- prepare_fpkm_and_z_log2(expr_tbl)
Z_log2_full <- prep$Z_log2
sample_names_full <- prep$sample_names
sample_group_full <- prep$sample_group

run_main_analysis <- function(Z_log2, sample_names, sample_group, n_hvg = 2000L) {
  ph <- pca_top_hvg(Z_log2, n_hvg)
  pca_result <- ph$pca_result
  take <- ph$take
  var_prop <- summary(pca_result)$importance[2, ]
  cum_prop <- summary(pca_result)$importance[3, ]

  scores_tbl <- scores_pc12_dataframe(pca_result, sample_names, sample_group)
  scores_tbl <- append_prefix_id(scores_tbl)

  axis <- disease_axis_scores_2d(scores_tbl)
  scores_tbl$score_raw <- axis$score_raw
  scores_tbl$score_z <- axis$score_z
  v <- axis$v

  group_mean <- tapply(scores_tbl$score_raw, scores_tbl$group, mean)
  mean_HC <- unname(group_mean["HC"])
  mean_SLE <- unname(group_mean["SLE"])
  mean_SLET <- unname(group_mean["SLET"])
  ordering_ok <- isTRUE(mean_HC < mean_SLET && mean_SLET < mean_SLE)

  pair_tbl <- paired_response_table(scores_tbl, v)

  list(
    pca_result = pca_result,
    scores_tbl = scores_tbl,
    pair_tbl = pair_tbl,
    v = v,
    mu_HC = axis$mu_HC,
    mu_SLE = axis$mu_SLE,
    take = take,
    pc1_pct = 100 * var_prop[1],
    pc2_pct = 100 * var_prop[2],
    pc12_pct = 100 * cum_prop[2],
    mean_HC = mean_HC,
    mean_SLET = mean_SLET,
    mean_SLE = mean_SLE,
    ordering_ok = ordering_ok,
    n_pairs = nrow(pair_tbl),
    n_toward_health = sum(pair_tbl$delta_s_raw < 0, na.rm = TRUE)
  )
}

full_res <- run_main_analysis(
  Z_log2 = Z_log2_full,
  sample_names = sample_names_full,
  sample_group = sample_group_full,
  n_hvg = n_hvg
)

v_full <- full_res$v

#========================
# 3. leave-one-out
#========================
loo_summary_list <- list()
loo_pairs_list <- list()

for (i in seq_along(sample_names_full)) {

  left_out <- sample_names_full[i]

  keep_idx <- setdiff(seq_along(sample_names_full), i)
  Z_log2_loo <- Z_log2_full[keep_idx, , drop = FALSE]
  sample_names_loo <- sample_names_full[keep_idx]
  sample_group_loo <- sample_group_full[keep_idx]

  # 保证 HC 和 SLE 至少还能算 centroid
  if (sum(sample_group_loo == "HC") < 1 || sum(sample_group_loo == "SLE") < 1) {
    next
  }

  loo_res <- run_main_analysis(
    Z_log2 = Z_log2_loo,
    sample_names = sample_names_loo,
    sample_group = sample_group_loo,
    n_hvg = n_hvg
  )

  # disease axis 与 full-data axis 的夹角余弦
  axis_cosine_vs_full <- sum(loo_res$v * v_full)

  # paired结果里可能因为删掉一个 pre/post 样本而少一对
  loo_pair_tbl <- loo_res$pair_tbl
  loo_pair_tbl$left_out_sample <- left_out
  loo_pair_tbl$axis_cosine_vs_full <- axis_cosine_vs_full

  loo_summary_list[[left_out]] <- data.frame(
    left_out_sample = left_out,
    left_out_group = as.character(sample_group_full[i]),
    PC1_pct = round(loo_res$pc1_pct, 2),
    PC2_pct = round(loo_res$pc2_pct, 2),
    PC1_PC2_cumulative_pct = round(loo_res$pc12_pct, 2),
    mean_score_HC = loo_res$mean_HC,
    mean_score_SLET = loo_res$mean_SLET,
    mean_score_SLE = loo_res$mean_SLE,
    ordering_HC_lt_SLET_lt_SLE = loo_res$ordering_ok,
    n_pairs = loo_res$n_pairs,
    n_toward_health = loo_res$n_toward_health,
    prop_toward_health = round(loo_res$n_toward_health / loo_res$n_pairs, 3),
    axis_cosine_vs_full = round(axis_cosine_vs_full, 6),
    stringsAsFactors = FALSE
  )

  loo_pairs_list[[left_out]] <- loo_pair_tbl[, c(
    "left_out_sample", "axis_cosine_vs_full",
    "pair_id", "pre_sample", "post_sample",
    "delta_s_raw", "vector_length", "cos_theta", "direction_label"
  )]
}

loo_summary <- do.call(rbind, loo_summary_list)
loo_pairs <- do.call(rbind, loo_pairs_list)

#========================
# 4. full-data baseline 也导出
#========================
full_summary <- data.frame(
  analysis = "full_data",
  PC1_pct = round(full_res$pc1_pct, 2),
  PC2_pct = round(full_res$pc2_pct, 2),
  PC1_PC2_cumulative_pct = round(full_res$pc12_pct, 2),
  mean_score_HC = full_res$mean_HC,
  mean_score_SLET = full_res$mean_SLET,
  mean_score_SLE = full_res$mean_SLE,
  ordering_HC_lt_SLET_lt_SLE = full_res$ordering_ok,
  n_pairs = full_res$n_pairs,
  n_toward_health = full_res$n_toward_health,
  prop_toward_health = round(full_res$n_toward_health / full_res$n_pairs, 3),
  stringsAsFactors = FALSE
)

#========================
# 5. 写出结果
#========================
write.csv(
  full_summary,
  file.path(output_dir, "full_data_baseline_summary.csv"),
  row.names = FALSE
)

write.csv(
  loo_summary,
  file.path(output_dir, "loo_summary.csv"),
  row.names = FALSE
)

write.csv(
  loo_pairs,
  file.path(output_dir, "loo_pairs.csv"),
  row.names = FALSE
)

# 可选：给一个更简洁的鲁棒性表
loo_brief <- loo_summary[, c(
  "left_out_sample", "left_out_group",
  "ordering_HC_lt_SLET_lt_SLE",
  "n_pairs", "n_toward_health",
  "axis_cosine_vs_full"
)]

write.csv(
  loo_brief,
  file.path(output_dir, "loo_brief.csv"),
  row.names = FALSE
)

#========================
# 6. 控制台输出
#========================
cat("\n=== Full-data baseline ===\n")
print(full_summary, row.names = FALSE)

cat("\n=== LOO summary (first rows) ===\n")
print(head(loo_summary), row.names = FALSE)

cat("\n=== Robustness summary ===\n")
cat("Ordering HC < SLET < SLE preserved in:",
    sum(loo_summary$ordering_HC_lt_SLET_lt_SLE, na.rm = TRUE),
    "/", nrow(loo_summary), "LOO runs\n")

cat("Median axis cosine vs full-data axis:",
    round(median(loo_summary$axis_cosine_vs_full, na.rm = TRUE), 6), "\n")

cat("Range of n_toward_health:",
    paste(range(loo_summary$n_toward_health, na.rm = TRUE), collapse = " to "), "\n")

message("\n已写入目录：", output_dir)
message("主要文件：")
message("1) full_data_baseline_summary.csv")
message("2) loo_summary.csv")
message("3) loo_pairs.csv")
message("4) loo_brief.csv")