rm(list = ls())

ca <- commandArgs(trailingOnly = FALSE)
ff <- grep("^--file=", ca, value = TRUE)
rdir <- if (length(ff)) dirname(normalizePath(sub("^--file=", "", ff[1]))) else normalizePath(file.path(getwd(), "R"))
source(file.path(rdir, "ldaf_common.R"))

input_csv <- proj_path("results", "01_expr_filtered.csv")
output_dir <- proj_path("results")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

n_hvg <- 2000L

expr_tbl <- read.csv(input_csv, check.names = FALSE, stringsAsFactors = FALSE)
prep <- prepare_fpkm_and_z_log2(expr_tbl)
Z_log2 <- prep$Z_log2
sample_names <- prep$sample_names
sample_group <- prep$sample_group

ph <- pca_top_hvg(Z_log2, n_hvg)
pca_result <- ph$pca_result
take <- ph$take

var_prop <- summary(pca_result)$importance[2, ]
cum_prop <- summary(pca_result)$importance[3, ]

pca_variance_tbl <- data.frame(
  PC = paste0("PC", seq_along(var_prop)),
  variance_explained = as.numeric(var_prop),
  cumulative_variance = as.numeric(cum_prop),
  variance_explained_pct = round(100 * as.numeric(var_prop), 2),
  cumulative_variance_pct = round(100 * as.numeric(cum_prop), 2),
  stringsAsFactors = FALSE
)

write.csv(
  pca_variance_tbl,
  file.path(output_dir, "pca_variance_summary.csv"),
  row.names = FALSE
)

write.csv(
  head(pca_variance_tbl, 10),
  file.path(output_dir, "pca_variance_pc1_pc10.csv"),
  row.names = FALSE
)

scores_tbl <- scores_pc12_dataframe(pca_result, sample_names, sample_group)
write.csv(scores_tbl, file.path(output_dir, "pca_scores_pc1_pc2.csv"), row.names = FALSE)

pc1_pct <- 100 * as.numeric(var_prop[[1]])
pc2_pct <- 100 * as.numeric(var_prop[[2]])
cat(sprintf("top %d HVG | PC1: %.1f%%, PC2: %.1f%%\n", take, pc1_pct, pc2_pct))

group_colors <- c(HC = "#2E86AB", SLE = "#E94F37", SLET = "#6B4C9A")
pdf(file.path(output_dir, "pca_pc1_pc2.pdf"), width = 6.5, height = 5.5)
par(mar = c(4, 4, 3, 1) + 0.1)
plot(
  scores_tbl$PC1,
  scores_tbl$PC2,
  col = group_colors[as.character(sample_group)],
  pch = 16,
  cex = 1.3,
  xlab = sprintf("PC1 (%.1f%%)", pc1_pct),
  ylab = sprintf("PC2 (%.1f%%)", pc2_pct),
  main = sprintf("PCA (top %d HVG)", take)
)
legend(
  "topright",
  legend = levels(sample_group),
  col = group_colors[levels(sample_group)],
  pch = 16,
  bty = "n"
)
mtext(
  "rank: var on log2(FPKM+1); PCA: center + z-score genes",
  side = 3,
  line = 0.3,
  cex = 0.75,
  col = "gray30"
)
dev.off()

cat(sprintf("PC1+PC2 cumulative: %.2f%%\n", 100 * cum_prop[2]))

message("已写入：pca_variance_summary.csv, pca_variance_pc1_pc10.csv, pca_scores_pc1_pc2.csv, pca_pc1_pc2.pdf")
message("下一步: Rscript R/03_disease_axis_from_pca_scores.R")
