# Shared helpers for ldaf drivers (source from scripts under R/, do not run directly).

#' Resolve repository root when drivers live in \code{R/}.
#'
#' With \code{Rscript R/foo.R}, uses \verb{--file=} so the root is the parent of
#' \code{R/}. Without \verb{--file=}, assumes \code{getwd()} is the repository root.
#'
#' @return Normalized absolute path to project root.
proj_root <- function() {
  cmd <- commandArgs(trailingOnly = FALSE)
  m <- grep("^--file=", cmd, value = TRUE)
  if (length(m)) {
    script_dir <- dirname(normalizePath(sub("^--file=", "", m[1])))
    if (basename(script_dir) == "R") {
      return(dirname(script_dir))
    }
    return(script_dir)
  }
  normalizePath(getwd())
}

#' Path under project root.
#' @param ... Segments passed to \code{file.path}.
proj_path <- function(...) {
  file.path(proj_root(), ...)
}

#' Meta columns for filtered expression tables.
ldaf_meta_cols <- function() {
  c("gene_id", "gene_name", "gene_locus")
}

#' Map sample name prefix (A/D/B) to HC / SLE / SLET.
#'
#' @param sample_names Typically row names of the sample-by-gene log matrix.
#' @return Factor with levels \code{HC}, \code{SLE}, \code{SLET}.
sample_group_from_prefix <- function(sample_names) {
  prefix_letter <- toupper(substr(sample_names, 1, 1))
  prefix_to_group <- c(A = "HC", D = "SLE", B = "SLET")
  grp <- factor(
    unname(prefix_to_group[prefix_letter]),
    levels = c("HC", "SLE", "SLET")
  )
  if (anyNA(grp)) {
    stop("样本列名须为 A/B/D 前缀（对应 HC/SLE/SLET），否则请修改 prefix_to_group。")
  }
  grp
}

#' FPKM matrix, sample-by-gene \eqn{log2(FPKM+1)} matrix, and group factor.
#'
#' @param expr_tbl \code{read.csv} result on \code{01_expr_filtered.csv}.
#' @return List with \code{fpkm_mat}, \code{sample_cols}, \code{Z_log2},
#'   \code{sample_names}, \code{sample_group}.
prepare_fpkm_and_z_log2 <- function(expr_tbl, meta_cols = ldaf_meta_cols()) {
  sample_cols <- setdiff(names(expr_tbl), meta_cols)
  fpkm_mat <- as.matrix(expr_tbl[, sample_cols, drop = FALSE])
  storage.mode(fpkm_mat) <- "double"
  Z_log2 <- t(log2(fpkm_mat + 1))
  sample_names <- rownames(Z_log2)
  list(
    fpkm_mat = fpkm_mat,
    sample_cols = sample_cols,
    Z_log2 = Z_log2,
    sample_names = sample_names,
    sample_group = sample_group_from_prefix(sample_names)
  )
}

#' PCA on top HVGs by variance on the log2 matrix; genes centered and scaled.
#'
#' @param Z_log2 Sample-by-gene matrix.
#' @param n_hvg Number of genes to keep.
#' @return List: \code{pca_result}, \code{take}, \code{Z_hvg}, \code{ord},
#'   \code{gene_var}.
pca_top_hvg <- function(Z_log2, n_hvg) {
  gene_var <- apply(Z_log2, 2L, stats::var)
  ord <- order(gene_var, decreasing = TRUE)
  take <- min(as.integer(n_hvg), ncol(Z_log2))
  Z_hvg <- Z_log2[, ord[seq_len(take)], drop = FALSE]
  pca_result <- stats::prcomp(Z_hvg, center = TRUE, scale. = TRUE)
  list(
    pca_result = pca_result,
    take = take,
    Z_hvg = Z_hvg,
    ord = ord,
    gene_var = gene_var
  )
}

#' PC1 and PC2 scores as a data.frame.
scores_pc12_dataframe <- function(pca_result, sample_names, sample_group) {
  data.frame(
    sample = sample_names,
    group = sample_group,
    PC1 = pca_result$x[, 1],
    PC2 = pca_result$x[, 2],
    stringsAsFactors = FALSE
  )
}

#' HC-centered disease score on the axis from HC toward untreated SLE (2D).
#'
#' @param scores_pc12 Columns \code{PC1}, \code{PC2}, \code{group}.
#' @return List \code{mu_HC}, \code{mu_SLE}, \code{v}, \code{score_raw}, \code{score_z}.
disease_axis_scores_2d <- function(scores_pc12) {
  mu_HC <- colMeans(scores_pc12[scores_pc12$group == "HC", c("PC1", "PC2"), drop = FALSE])
  mu_SLE <- colMeans(scores_pc12[scores_pc12$group == "SLE", c("PC1", "PC2"), drop = FALSE])
  v_raw <- mu_SLE - mu_HC
  v <- v_raw / sqrt(sum(v_raw^2))
  Y <- as.matrix(scores_pc12[, c("PC1", "PC2")])
  Y_centered <- sweep(Y, 2, mu_HC, FUN = "-")
  score_raw <- as.numeric(Y_centered %*% v)
  score_z <- as.numeric(scale(score_raw))
  list(mu_HC = mu_HC, mu_SLE = mu_SLE, v = v, score_raw = score_raw, score_z = score_z)
}

#' Add \code{prefix} and \code{id_num} from sample IDs (e.g. D2 -> D, 2).
append_prefix_id <- function(tbl, sample_col = "sample") {
  s <- tbl[[sample_col]]
  tbl$prefix <- toupper(substr(s, 1, 1))
  tbl$id_num <- sub("^[A-Za-z]+", "", s)
  tbl
}

#' Paired pre/post displacement and alignment with disease axis \code{v}.
paired_response_table <- function(scores_tbl, v) {
  pre_df <- scores_tbl[scores_tbl$prefix == "D", c("sample", "group", "PC1", "PC2", "score_raw", "score_z", "id_num")]
  post_df <- scores_tbl[scores_tbl$prefix == "B", c("sample", "group", "PC1", "PC2", "score_raw", "score_z", "id_num")]
  names(pre_df) <- c("pre_sample", "pre_group", "pre_PC1", "pre_PC2", "pre_score_raw", "pre_score_z", "id_num")
  names(post_df) <- c("post_sample", "post_group", "post_PC1", "post_PC2", "post_score_raw", "post_score_z", "id_num")
  pair_tbl <- merge(pre_df, post_df, by = "id_num", all = FALSE)
  pair_tbl <- pair_tbl[order(as.numeric(pair_tbl$id_num)), ]
  pair_tbl$delta_PC1 <- pair_tbl$post_PC1 - pair_tbl$pre_PC1
  pair_tbl$delta_PC2 <- pair_tbl$post_PC2 - pair_tbl$pre_PC2
  pair_tbl$delta_s_raw <- pair_tbl$post_score_raw - pair_tbl$pre_score_raw
  pair_tbl$delta_s_z <- pair_tbl$post_score_z - pair_tbl$pre_score_z
  pair_tbl$vector_length <- sqrt(pair_tbl$delta_PC1^2 + pair_tbl$delta_PC2^2)
  pair_tbl$cos_theta <- (pair_tbl$delta_PC1 * v[1] + pair_tbl$delta_PC2 * v[2]) / pair_tbl$vector_length
  pair_tbl$cos_theta[!is.finite(pair_tbl$cos_theta)] <- NA
  pair_tbl$direction_label <- ifelse(
    pair_tbl$delta_s_raw < 0,
    "toward_health",
    "non_improving_or_opposite"
  )
  pair_tbl$pair_id <- paste0("Pair_", pair_tbl$id_num)
  pair_tbl
}
