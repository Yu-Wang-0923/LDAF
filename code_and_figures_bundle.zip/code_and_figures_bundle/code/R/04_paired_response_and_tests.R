rm(list = ls())

ca <- commandArgs(trailingOnly = FALSE)
ff <- grep("^--file=", ca, value = TRUE)
rdir <- if (length(ff)) dirname(normalizePath(sub("^--file=", "", ff[1]))) else normalizePath(file.path(getwd(), "R"))
source(file.path(rdir, "ldaf_common.R"))

input_scores <- proj_path("results", "disease_axis_scores.csv")
output_dir <- proj_path("results")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

df <- read.csv(input_scores, stringsAsFactors = FALSE, check.names = FALSE)

required_cols <- c("sample", "group", "PC1", "PC2", "score_raw", "score_z")
miss_cols <- setdiff(required_cols, names(df))
if (length(miss_cols) > 0) {
  stop("缺少必要列: ", paste(miss_cols, collapse = ", "))
}

axis <- disease_axis_scores_2d(df[, c("sample", "group", "PC1", "PC2")])
v <- axis$v

df$group[df$group == "SLET"] <- "SLE_post"

work <- append_prefix_id(df[, required_cols])
pair_tbl <- paired_response_table(work, v)

pair_tbl <- pair_tbl[, c(
  "pair_id", "id_num",
  "pre_sample", "post_sample",
  "pre_group", "post_group",
  "pre_PC1", "pre_PC2",
  "post_PC1", "post_PC2",
  "delta_PC1", "delta_PC2",
  "vector_length",
  "pre_score_raw", "post_score_raw", "delta_s_raw",
  "pre_score_z", "post_score_z", "delta_s_z",
  "cos_theta",
  "direction_label"
)]

write.csv(
  pair_tbl,
  file.path(output_dir, "paired_response_summary.csv"),
  row.names = FALSE
)

pair_brief <- pair_tbl[, c(
  "pair_id", "pre_sample", "post_sample",
  "delta_s_raw", "vector_length", "cos_theta", "direction_label"
)]

write.csv(
  pair_brief,
  file.path(output_dir, "paired_response_brief.csv"),
  row.names = FALSE
)

cat("配对样本数：", nrow(pair_tbl), "\n\n")

cat("各配对样本的 delta_s_raw：\n")
print(pair_tbl[, c("pair_id", "pre_sample", "post_sample", "delta_s_raw", "direction_label")], row.names = FALSE)

cat("\n朝健康方向移动的配对数（delta_s_raw < 0）：",
    sum(pair_tbl$delta_s_raw < 0, na.rm = TRUE), "/", nrow(pair_tbl), "\n")

cat("\nDisease axis unit vector v:\n")
print(v)

message("\n已写入：paired_response_summary.csv, paired_response_brief.csv")

delta_s <- pair_tbl$delta_s_raw
delta_s <- delta_s[is.finite(delta_s)]

if (length(delta_s) == 0) {
  stop("没有可用的 delta_s_raw 数据。")
}

n_total <- length(delta_s)
n_negative <- sum(delta_s < 0)
n_positive <- sum(delta_s > 0)
n_zero <- sum(delta_s == 0)

desc_tbl <- data.frame(
  n_total = n_total,
  n_negative = n_negative,
  n_positive = n_positive,
  n_zero = n_zero,
  median_delta_s = median(delta_s),
  mean_delta_s = mean(delta_s),
  sd_delta_s = sd(delta_s),
  min_delta_s = min(delta_s),
  max_delta_s = max(delta_s)
)

write.csv(
  desc_tbl,
  file.path(output_dir, "paired_delta_s_descriptive_stats.csv"),
  row.names = FALSE
)

delta_nonzero <- delta_s[delta_s != 0]
n_nonzero <- length(delta_nonzero)
n_neg_nonzero <- sum(delta_nonzero < 0)

sign_test <- binom.test(
  x = n_neg_nonzero,
  n = n_nonzero,
  p = 0.5,
  alternative = "greater"
)

sign_tbl <- data.frame(
  test = "exact_binomial_sign_test",
  n_nonzero = n_nonzero,
  n_negative = n_neg_nonzero,
  p_value = sign_test$p.value,
  estimate_prob_negative = unname(sign_test$estimate),
  conf_low_95 = sign_test$conf.int[1],
  conf_high_95 = sign_test$conf.int[2],
  alternative = "P(delta_s < 0) > 0.5"
)

write.csv(
  sign_tbl,
  file.path(output_dir, "paired_delta_s_sign_test.csv"),
  row.names = FALSE
)

wilcox_res <- wilcox.test(
  x = delta_s,
  mu = 0,
  alternative = "less",
  paired = FALSE,
  exact = TRUE,
  conf.int = TRUE,
  conf.level = 0.95
)

wilcox_tbl <- data.frame(
  test = "wilcoxon_signed_rank_test",
  n = n_total,
  statistic = unname(wilcox_res$statistic),
  p_value = wilcox_res$p.value,
  estimate = if (!is.null(wilcox_res$estimate)) unname(wilcox_res$estimate) else NA_real_,
  conf_low_95 = if (!is.null(wilcox_res$conf.int)) wilcox_res$conf.int[1] else NA_real_,
  conf_high_95 = if (!is.null(wilcox_res$conf.int)) wilcox_res$conf.int[2] else NA_real_,
  alternative = "median(delta_s) < 0"
)

write.csv(
  wilcox_tbl,
  file.path(output_dir, "paired_delta_s_wilcoxon_test.csv"),
  row.names = FALSE
)

summary_tbl <- rbind(
  data.frame(
    analysis = "descriptive",
    n = n_total,
    value1 = n_negative,
    value2 = n_positive,
    value3 = n_zero,
    p_value = NA_real_,
    note = "value1=n_negative, value2=n_positive, value3=n_zero"
  ),
  data.frame(
    analysis = "sign_test",
    n = n_nonzero,
    value1 = n_neg_nonzero,
    value2 = NA_real_,
    value3 = NA_real_,
    p_value = sign_test$p.value,
    note = "value1=n_negative among nonzero delta_s"
  ),
  data.frame(
    analysis = "wilcoxon_signed_rank",
    n = n_total,
    value1 = unname(wilcox_res$statistic),
    value2 = NA_real_,
    value3 = NA_real_,
    p_value = wilcox_res$p.value,
    note = "value1=Wilcoxon statistic"
  )
)

write.csv(
  summary_tbl,
  file.path(output_dir, "paired_delta_s_tests_summary.csv"),
  row.names = FALSE
)

cat("\n=== Descriptive summary of paired delta_s ===\n")
print(desc_tbl, row.names = FALSE)

cat("\n=== Exact binomial sign test ===\n")
print(sign_tbl, row.names = FALSE)

cat("\n=== Wilcoxon signed-rank test ===\n")
print(wilcox_tbl, row.names = FALSE)

message("\n已写入：paired_delta_s_descriptive_stats.csv, paired_delta_s_sign_test.csv,")
message("         paired_delta_s_wilcoxon_test.csv, paired_delta_s_tests_summary.csv")
