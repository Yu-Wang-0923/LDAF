rm(list = ls())

ca <- commandArgs(trailingOnly = FALSE)
ff <- grep("^--file=", ca, value = TRUE)
rdir <- if (length(ff)) dirname(normalizePath(sub("^--file=", "", ff[1]))) else normalizePath(file.path(getwd(), "R"))
source(file.path(rdir, "ldaf_common.R"))

input_csv <- proj_path("results", "pca_scores_pc1_pc2.csv")
output_dir <- proj_path("results")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

scores_tbl <- read.csv(input_csv, check.names = FALSE, stringsAsFactors = FALSE)
need <- c("sample", "group", "PC1", "PC2")
miss <- setdiff(need, names(scores_tbl))
if (length(miss)) {
  stop("pca_scores_pc1_pc2.csv 缺少列: ", paste(miss, collapse = ", "))
}

axis <- disease_axis_scores_2d(scores_tbl)
mu_HC <- axis$mu_HC
mu_SLE <- axis$mu_SLE
v <- axis$v

disease_axis_tbl <- cbind(
  scores_tbl,
  score_raw = axis$score_raw,
  score_z = axis$score_z
)

write.csv(
  disease_axis_tbl,
  file.path(output_dir, "disease_axis_scores.csv"),
  row.names = FALSE
)

axis_tbl <- data.frame(
  item = c("mu_HC_PC1", "mu_HC_PC2", "mu_SLE_PC1", "mu_SLE_PC2", "v_PC1", "v_PC2"),
  value = c(mu_HC[1], mu_HC[2], mu_SLE[1], mu_SLE[2], v[1], v[2])
)

write.csv(
  axis_tbl,
  file.path(output_dir, "disease_axis_definition.csv"),
  row.names = FALSE
)

var_path <- file.path(output_dir, "pca_variance_summary.csv")
if (file.exists(var_path)) {
  pv <- read.csv(var_path, stringsAsFactors = FALSE)
  cat(sprintf("PC1: %.2f%%, PC2: %.2f%% (from pca_variance_summary.csv)\n",
              pv$variance_explained_pct[1], pv$variance_explained_pct[2]))
}

cat("\nHC centroid:\n")
print(mu_HC)

cat("\nSLE centroid:\n")
print(mu_SLE)

cat("\nDisease axis unit vector v:\n")
print(v)

cat("\nGroup-wise mean raw score:\n")
print(tapply(disease_axis_tbl$score_raw, disease_axis_tbl$group, mean))

message("已写入：disease_axis_scores.csv, disease_axis_definition.csv")
