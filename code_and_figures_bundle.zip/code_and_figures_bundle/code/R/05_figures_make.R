#!/usr/bin/env Rscript
# Exports figures into figures/: base-R panels + ggplot Fig 2 / Fig 3 (match figs1 originals).

rm(list = ls())

ca <- commandArgs(trailingOnly = FALSE)
ff <- grep("^--file=", ca, value = TRUE)
rdir <- if (length(ff)) dirname(normalizePath(sub("^--file=", "", ff[1]))) else normalizePath(file.path(getwd(), "R"))
source(file.path(rdir, "ldaf_common.R"))
res <- proj_path("results")
fig <- proj_path("figures")
dir.create(fig, showWarnings = FALSE, recursive = TRUE)

# PCA loadings sign is arbitrary; multiply PC1 by -1 when needed so HC centroid is left of non-HC.
sign_pc1_hc_left <- function(pc1, is_hc) {
  if (!any(is_hc) || all(is_hc)) return(1L)
  m_h <- mean(pc1[is_hc], na.rm = TRUE)
  m_o <- mean(pc1[!is_hc], na.rm = TRUE)
  if (!is.finite(m_h) || !is.finite(m_o)) return(1L)
  if (m_h > m_o) -1L else 1L
}

pca_var <- read.csv(file.path(res, "pca_variance_summary.csv"), stringsAsFactors = FALSE)
pc1p <- pca_var$variance_explained_pct[1]
pc2p <- pca_var$variance_explained_pct[2]

pca <- read.csv(file.path(res, "pca_scores_pc1_pc2.csv"), stringsAsFactors = FALSE)
scores <- read.csv(file.path(res, "disease_axis_scores.csv"), stringsAsFactors = FALSE)
pair <- read.csv(file.path(res, "paired_response_summary.csv"), stringsAsFactors = FALSE)

# Palette aligned with figs1/Fig2.jpg and figs1/fig 3.jpg (HC pink, SLE green, SLET blue)
col_group <- c(HC = "#F48FB1", SLE = "#66BB6A", SLET = "#42A5F5", SLE_post = "#42A5F5")
pca$col <- unname(col_group[as.character(pca$group)])
flip1_sle <- sign_pc1_hc_left(pca$PC1, pca$group == "HC")
pca$PC1 <- pca$PC1 * flip1_sle
pair$pre_PC1 <- pair$pre_PC1 * flip1_sle
pair$post_PC1 <- pair$post_PC1 * flip1_sle

# ---- Fig: PCA PC1–PC2 with variance on axes ----
plot_pca <- function() {
  par(mar = c(4, 4, 2, 1) + 0.1)
  plot(
    pca$PC1, pca$PC2, col = pca$col, pch = 16, cex = 1.2,
    xlab = sprintf("PC1 (%.2f%% variance)", pc1p),
    ylab = sprintf("PC2 (%.2f%% variance)", pc2p),
    main = "PCA (top 2000 HVG, log2 FPKM+1)"
  )
  legend(
    "topright",
    legend = c("HC", "SLE", "SLET"),
    col = c(col_group[["HC"]], col_group[["SLE"]], col_group[["SLET"]]),
    pch = 16, bty = "n", cex = 0.85
  )
}
pdf(file.path(fig, "Fig_PCA_PC1_PC2.pdf"), width = 6.5, height = 5.5)
plot_pca()
dev.off()
png(file.path(fig, "Fig_PCA_PC1_PC2.png"), width = 1800, height = 1500, res = 200)
plot_pca()
dev.off()

# ---- Fig: paired delta_s (spaghetti by patient) ----
plot_pairs <- function() {
  par(mar = c(4, 4, 2, 1) + 0.1)
  xs <- rbind(pair$pre_score_raw, pair$post_score_raw)
  col_delta <- ifelse(pair$delta_s_raw < 0, "#1976D2", ifelse(pair$delta_s_raw > 0, "#E53935", "gray50"))
  plot(
    NULL, xlim = c(0.8, 2.2), ylim = range(xs, na.rm = TRUE),
    xlab = "", ylab = "HC-centered disease-axis score", xaxt = "n",
    main = "Paired pre/post along disease axis (n=6)"
  )
  axis(1, at = 1:2, labels = c("SLE", "SLET"))
  for (i in seq_len(nrow(pair))) {
    lines(c(1, 2), c(pair$pre_score_raw[i], pair$post_score_raw[i]), col = col_delta[i], lwd = 2)
    points(c(1, 2), c(pair$pre_score_raw[i], pair$post_score_raw[i]), pch = 16, col = col_delta[i], cex = 1)
  }
  legend(
    "topleft",
    legend = c(expression(Delta * s < 0 ~ "(toward healthy on axis)"), expression(Delta * s >= 0)),
    col = c("#1976D2", "#E53935"), lwd = 2, bty = "n", cex = 0.75
  )
}
pdf(file.path(fig, "Fig_paired_delta_s.pdf"), width = 5.5, height = 5)
plot_pairs()
dev.off()
png(file.path(fig, "Fig_paired_delta_s.png"), width = 1400, height = 1300, res = 200)
plot_pairs()
dev.off()

# ---- Fig: displacement vectors in PC1–PC2 ----
plot_vec <- function() {
  par(mar = c(4, 4, 2, 1) + 0.1)
  col_delta <- ifelse(pair$delta_s_raw < 0, "#1976D2", ifelse(pair$delta_s_raw > 0, "#E53935", "gray50"))
  xr <- range(c(pca$PC1, pair$pre_PC1, pair$post_PC1), na.rm = TRUE)
  yr <- range(c(pca$PC2, pair$pre_PC2, pair$post_PC2), na.rm = TRUE)
  plot(
    pca$PC1, pca$PC2, col = adjustcolor(pca$col, 0.35), pch = 16, cex = 1,
    xlab = sprintf("PC1 (%.2f%%)", pc1p), ylab = sprintf("PC2 (%.2f%%)", pc2p),
    main = "Treatment displacement vectors (PC1–PC2)", xlim = xr, ylim = yr
  )
  legend("topright", legend = c("HC", "SLE", "SLET"), col = adjustcolor(c(col_group), 0.5),
         pch = 16, bty = "n", cex = 0.8)
  for (i in seq_len(nrow(pair))) {
    arrows(
      pair$pre_PC1[i], pair$pre_PC2[i],
      pair$post_PC1[i], pair$post_PC2[i],
      length = 0.08, lwd = 2, col = col_delta[i]
    )
  }
}
pdf(file.path(fig, "Fig_treatment_vectors_PC12.pdf"), width = 6.5, height = 5.5)
plot_vec()
dev.off()
png(file.path(fig, "Fig_treatment_vectors_PC12.png"), width = 1800, height = 1500, res = 200)
plot_vec()
dev.off()

# ---- Fig 2 & Fig 3 (ggplot): match figs1/Fig2.jpg and figs1/fig 3.jpg ----
pca_ellipse_df <- function(df, level = 0.95) {
  gn <- unique(as.character(df$group))
  pieces <- lapply(gn, function(g) {
    s <- df[df$group == g, c("PC1", "PC2"), drop = FALSE]
    if (nrow(s) < 3L) return(NULL)
    mu <- colMeans(s)
    S <- stats::cov(s)
    if (any(!is.finite(S)) || det(S) < 1e-20) return(NULL)
    ed <- eigen(S, symmetric = TRUE)
    rv <- pmax(Re(ed$values[1:2]), 1e-12)
    a <- sqrt(stats::qchisq(level, df = 2L))
    tt <- seq(0, 2 * pi, length.out = 100L)
    xy <- cbind(a * sqrt(rv[1L]) * cos(tt), a * sqrt(rv[2L]) * sin(tt)) %*% t(ed$vectors[, 1:2, drop = FALSE])
    data.frame(PC1 = xy[, 1L] + mu[1L], PC2 = xy[, 2L] + mu[2L], group = g, piece = g)
  })
  pieces <- Filter(Negate(is.null), pieces)
  if (!length(pieces)) return(NULL)
  do.call(rbind, pieces)
}

if (requireNamespace("ggplot2", quietly = TRUE) && requireNamespace("patchwork", quietly = TRUE) &&
    requireNamespace("tidyr", quietly = TRUE)) {
  library(ggplot2)
  library(patchwork)
  library(tidyr)

  theme_fig_manuscript <- function() {
    theme_bw(base_size = 11) +
      theme(
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        plot.title = element_text(face = "bold", size = 12),
        axis.title = element_text(face = "plain"),
        panel.border = element_rect(colour = "grey30", fill = NA, linewidth = 0.4)
      )
  }

  pal_grp <- c(HC = "#F48FB1", SLE = "#66BB6A", SLET = "#42A5F5")
  pal_fill_v <- c(HC = "#FCE4EC", SLE = "#E8F5E9", SLET = "#E3F2FD")
  pal_line_b <- c(Improved = "#00897B", `Minimal change` = "#7E57C2")
  col_toward <- "#1976D2"
  col_away <- "#E53935"

  sc <- scores
  sc$grp <- factor(sc$group, levels = c("HC", "SLE", "SLET"))

  p2a <- ggplot(sc, aes(x = grp, y = score_z, fill = grp, colour = grp)) +
    geom_violin(width = 0.88, alpha = 0.9, trim = FALSE, adjust = 1.35, linewidth = 0.35) +
    geom_boxplot(width = 0.11, outlier.shape = NA, linewidth = 0.5, fill = "white", alpha = 1) +
    geom_jitter(
      position = position_jitter(width = 0.18, height = 0, seed = 2),
      size = 2, shape = 21,
      fill = "white", colour = "grey25", stroke = 0.35
    ) +
    scale_fill_manual(values = pal_fill_v, guide = "none") +
    scale_colour_manual(values = pal_grp, guide = "none") +
    scale_x_discrete(expand = expansion(add = 0.14)) +
    labs(
      x = NULL,
      title = "(a) Disease-axis projection score",
      y = expression("Axis score (" * z * "; higher = more SLE-like)")
    ) +
    theme_fig_manuscript()

  pair$outcome <- ifelse(pair$delta_s_raw < 0, "Improved", "Minimal change")
  pair$col_b <- ifelse(pair$delta_s_raw < 0, pal_line_b[["Improved"]], pal_line_b[["Minimal change"]])
  pair$patient_lab <- factor(
    paste("Patient", seq_len(nrow(pair))),
    levels = paste("Patient", seq_len(nrow(pair)))
  )

  pl2b <- tidyr::pivot_longer(
    pair[, c("pair_id", "pre_score_z", "post_score_z", "col_b")],
    cols = c(pre_score_z, post_score_z),
    names_to = "tname",
    values_to = "score_z"
  )
  pl2b$time <- factor(
    ifelse(pl2b$tname == "pre_score_z", "SLE", "SLET"),
    levels = c("SLE", "SLET")
  )

  p2b <- ggplot(pl2b, aes(x = time, y = score_z, group = pair_id)) +
    geom_line(aes(colour = I(col_b)), linewidth = 0.9) +
    geom_point(aes(colour = I(col_b)), size = 2.4) +
    labs(
      x = NULL,
      y = expression("Axis score (" * z * ")"),
      title = "(b) Paired shift along disease axis"
    ) +
    theme_fig_manuscript()

  pl2c <- tidyr::pivot_longer(
    pair[, c("patient_lab", "pre_score_z", "post_score_z", "outcome")],
    cols = c(pre_score_z, post_score_z),
    names_to = "tname",
    values_to = "score_z"
  )
  pl2c$time <- factor(ifelse(pl2c$tname == "pre_score_z", "SLE", "SLET"), levels = c("SLE", "SLET"))

  p2c <- ggplot(pl2c, aes(x = time, y = score_z, group = patient_lab)) +
    geom_line(aes(colour = outcome), linewidth = 0.85) +
    geom_point(aes(fill = outcome), size = 2.6, shape = 21, colour = "grey30", stroke = 0.35) +
    facet_wrap(~patient_lab, nrow = 2L, ncol = 3L) +
    scale_colour_manual(values = pal_line_b, name = NULL) +
    scale_fill_manual(values = pal_line_b, name = NULL) +
    labs(x = NULL, y = expression("Axis score (" * z * ")"), title = "(c) Paired treatment trajectories") +
    theme_fig_manuscript() +
    theme(legend.position = "bottom")

  fig2 <- (p2a | p2b) / p2c + plot_layout(heights = c(0.42, 0.58), widths = c(1, 1))

  tryCatch(
    ggsave(file.path(fig, "Fig2_disease_axis_and_paired.pdf"), fig2, width = 10, height = 9, device = grDevices::cairo_pdf),
    error = function(e) ggsave(file.path(fig, "Fig2_disease_axis_and_paired.pdf"), fig2, width = 10, height = 9)
  )
  ggsave(
    file.path(fig, "Fig2_disease_axis_and_paired.png"),
    fig2, width = 10, height = 9, dpi = 600, bg = "white"
  )

  pca_plot <- pca
  pca_plot$grp <- factor(pca_plot$group, levels = c("HC", "SLE", "SLET"))
  ell <- pca_ellipse_df(pca_plot)
  if (!is.null(ell)) ell$grp <- factor(ell$group, levels = c("HC", "SLE", "SLET"))

  p3a <- ggplot()
  if (!is.null(ell)) {
    p3a <- p3a + geom_path(data = ell, aes(PC1, PC2, group = piece, colour = grp), linewidth = 0.55)
  }
  p3a <- p3a +
    geom_point(data = pca_plot, aes(PC1, PC2, colour = grp), size = 2.5) +
    geom_text(
      data = pca_plot,
      aes(PC1, PC2, label = sample, colour = grp),
      size = 2.5, vjust = -0.65, show.legend = FALSE
    ) +
    scale_colour_manual(values = pal_grp, name = NULL) +
    coord_cartesian(clip = "off") +
    labs(
      title = "(a) PCA of samples based on gene expression",
      x = sprintf("PC1 (%.1f%%)", pc1p),
      y = sprintf("PC2 (%.1f%%)", pc2p)
    ) +
    theme_fig_manuscript() +
    theme(legend.position = c(0.02, 0.98), legend.justification = c(0, 1))

  pair$arrow_lab <- ifelse(pair$delta_s_raw < 0, "Toward healthy", "Away / minimal")
  hc_pts <- pca_plot[pca_plot$grp == "HC", , drop = FALSE]
  dis_pts <- pca_plot[pca_plot$grp != "HC", , drop = FALSE]

  p3b <- ggplot() +
    geom_point(
      data = hc_pts,
      aes(PC1, PC2, fill = grp),
      shape = 21,
      colour = "grey40",
      stroke = 0.25,
      size = 2.9,
      alpha = 0.38
    ) +
    geom_point(
      data = dis_pts,
      aes(PC1, PC2, fill = grp),
      shape = 21,
      colour = "grey25",
      stroke = 0.3,
      size = 3,
      alpha = 1
    ) +
    scale_fill_manual(values = pal_grp, name = NULL) +
    geom_segment(
      data = pair,
      aes(
        x = pre_PC1, y = pre_PC2, xend = post_PC1, yend = post_PC2,
        colour = arrow_lab
      ),
      arrow = grid::arrow(length = grid::unit(0.022, "npc"), type = "closed"),
      linewidth = 0.75
    ) +
    scale_colour_manual(
      values = c("Toward healthy" = col_toward, "Away / minimal" = col_away),
      name = NULL
    ) +
    labs(
      title = "(b) Treatment vectors in latent manifold",
      x = "Latent-1 (PC1)",
      y = "Latent-2 (PC2)"
    ) +
    theme_fig_manuscript() +
    theme(legend.position = c(0.98, 0.02), legend.justification = c(1, 0))

  fig3 <- p3a | p3b

  tryCatch(
    ggsave(file.path(fig, "Fig3_PCA_and_treatment_vectors.pdf"), fig3, width = 12, height = 5.5, device = grDevices::cairo_pdf),
    error = function(e) ggsave(file.path(fig, "Fig3_PCA_and_treatment_vectors.pdf"), fig3, width = 12, height = 5.5)
  )
  ggsave(
    file.path(fig, "Fig3_PCA_and_treatment_vectors.png"),
    fig3, width = 12, height = 5.5, dpi = 600, bg = "white"
  )

  # ---- Disease axis only (PC1–PC2): HC centroid → untreated SLE centroid ----
  pca_dax <- pca
  pca_dax$grp <- factor(pca_dax$group, levels = c("HC", "SLE", "SLET"))
  mu_h_sle <- colMeans(pca_dax[pca_dax$group == "HC", c("PC1", "PC2"), drop = FALSE])
  mu_u_sle <- colMeans(pca_dax[pca_dax$group == "SLE", c("PC1", "PC2"), drop = FALSE])
  seg_sle <- data.frame(
    x = mu_h_sle[1L], y = mu_h_sle[2L],
    xend = mu_u_sle[1L], yend = mu_u_sle[2L]
  )
  p_dax_sle <- ggplot(pca_dax, aes(PC1, PC2)) +
    geom_point(aes(colour = grp), size = 2.8) +
    scale_colour_manual(values = pal_grp, name = NULL) +
    geom_segment(
      data = seg_sle,
      aes(x = x, y = y, xend = xend, yend = yend),
      inherit.aes = FALSE,
      colour = "grey15",
      linewidth = 0.95,
      arrow = grid::arrow(length = grid::unit(0.032, "npc"), type = "closed")
    ) +
    coord_cartesian(clip = "off") +
    labs(
      title = "Disease axis (primary PBMC cohort)",
      subtitle = "Arrow: HC centroid \u2192 untreated SLE centroid (PC1\u2013PC2; same orientation as Fig. 3)",
      x = sprintf("PC1 (%.1f%% variance)", pc1p),
      y = sprintf("PC2 (%.1f%% variance)", pc2p)
    ) +
    theme_fig_manuscript() +
    theme(legend.position = c(0.02, 0.98), legend.justification = c(0, 1))

  tryCatch(
    ggsave(
      file.path(fig, "Fig_disease_axis_primary_PBMC.pdf"),
      p_dax_sle, width = 5.8, height = 5, device = grDevices::cairo_pdf
    ),
    error = function(e) ggsave(file.path(fig, "Fig_disease_axis_primary_PBMC.pdf"), p_dax_sle, width = 5.8, height = 5)
  )
  ggsave(
    file.path(fig, "Fig_disease_axis_primary_PBMC.png"),
    p_dax_sle, width = 5.8, height = 5, dpi = 600, bg = "white"
  )
}
gse_dir <- file.path(res, "gse235357")
gse_sc <- file.path(gse_dir, "gse235357_axis_scores.csv")
gse_pr <- file.path(gse_dir, "gse235357_paired_response_summary.csv")
gse_ax <- file.path(gse_dir, "gse235357_axis_definition.csv")

if (file.exists(gse_sc) && file.exists(gse_pr) && file.exists(gse_ax)) {
  if (!requireNamespace("ggplot2", quietly = TRUE) || !requireNamespace("patchwork", quietly = TRUE) ||
      !requireNamespace("tidyr", quietly = TRUE)) {
    message(
      "Skipping Fig_GSE235357 ggplot composite: install ggplot2, patchwork, tidyr for Fig2-matched layout."
    )
  } else {
    library(ggplot2)
    library(patchwork)
    library(tidyr)

    gs <- read.csv(gse_sc, stringsAsFactors = FALSE)
    gp <- read.csv(gse_pr, stringsAsFactors = FALSE)
    ga <- read.csv(gse_ax, stringsAsFactors = FALSE)
    pc1_ms <- ga$value[ga$item == "PC1_pct"]
    pc2_ms <- ga$value[ga$item == "PC2_pct"]

    flip1_gse <- sign_pc1_hc_left(gs$PC1, gs$timepoint == "hc")
    gs$PC1 <- gs$PC1 * flip1_gse
    gp$pre_PC1 <- gp$pre_PC1 * flip1_gse
    gp$post_PC1 <- gp$post_PC1 * flip1_gse

    theme_fig2a <- function() {
      theme_bw(base_size = 11) +
        theme(
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          plot.title = element_text(face = "bold", size = 12),
          axis.title = element_text(face = "plain"),
          panel.border = element_rect(colour = "grey30", fill = NA, linewidth = 0.4)
        )
    }

    pub_theme <- function() {
      theme_bw(base_size = 11) +
        theme(
          panel.grid.minor = element_blank(),
          plot.title = element_text(face = "bold", size = 12),
          axis.title = element_text(face = "plain"),
          legend.position = "right",
          strip.background = element_rect(fill = "grey92", colour = NA)
        )
    }

    # Same HC pink / pre green / post blue as main-text Fig 2 / Fig 3
    pal_three <- c(HC = "#F48FB1", `MS baseline` = "#66BB6A", `MS 12 mo` = "#42A5F5")
    pal_v_three <- c(HC = "#FCE4EC", `MS baseline` = "#E8F5E9", `MS 12 mo` = "#E3F2FD")
    pal_line_b <- c(Improved = "#00897B", `Minimal change` = "#7E57C2")
    col_toward <- "#1976D2"
    col_away <- "#E53935"

    gs$grp_plot <- factor(
      gs$timepoint,
      levels = c("hc", "baseline", "12m"),
      labels = c("HC", "MS baseline", "MS 12 mo")
    )

    p_gse_a <- ggplot(gs, aes(x = grp_plot, y = score_dis_z, fill = grp_plot, colour = grp_plot)) +
      geom_violin(width = 0.88, alpha = 0.9, trim = FALSE, adjust = 1.35, linewidth = 0.35) +
      geom_boxplot(width = 0.11, outlier.shape = NA, linewidth = 0.5, fill = "white", alpha = 1) +
      geom_jitter(
        position = position_jitter(width = 0.18, height = 0, seed = 3),
        size = 2, shape = 21, fill = "white", colour = "grey25", stroke = 0.35
      ) +
      scale_fill_manual(values = pal_v_three, guide = "none") +
      scale_colour_manual(values = pal_three, guide = "none") +
      scale_x_discrete(expand = ggplot2::expansion(add = 0.14)) +
      labs(
        x = NULL,
        title = "(a) Disease-axis projection score (GSE235357)",
        y = expression("Axis score (" * z * "; higher = more MS-baseline-like)")
      ) +
      theme_fig2a()

    gp$outcome <- ifelse(gp$delta_s_raw < 0, "Improved", "Minimal change")
    gp$col_b <- ifelse(gp$delta_s_raw < 0, pal_line_b[["Improved"]], pal_line_b[["Minimal change"]])
    gp$patient_lab <- factor(
      paste("Patient", seq_len(nrow(gp))),
      levels = paste("Patient", seq_len(nrow(gp)))
    )

    pl_g2b <- pivot_longer(
      gp[, c("pair_id", "pre_score_z", "post_score_z", "col_b")],
      cols = c(pre_score_z, post_score_z),
      names_to = "tname",
      values_to = "score_z"
    )
    pl_g2b$time <- factor(
      ifelse(pl_g2b$tname == "pre_score_z", "MS baseline", "MS 12 mo"),
      levels = c("MS baseline", "MS 12 mo")
    )

    p_gse_b2 <- ggplot(pl_g2b, aes(x = time, y = score_z, group = pair_id)) +
      geom_line(aes(colour = I(col_b)), linewidth = 0.85) +
      geom_point(aes(colour = I(col_b)), size = 2.2) +
      labs(
        x = NULL,
        y = expression("Disease-axis score (" * z * ")"),
        title = expression(paste(
          "(b) Paired shift along disease axis (",
          Delta * s < 0,
          ": toward HC)"
        ))
      ) +
      theme_fig2a()

    pl_g2c <- pivot_longer(
      gp[, c("patient_lab", "pre_score_z", "post_score_z", "outcome")],
      cols = c(pre_score_z, post_score_z),
      names_to = "tname",
      values_to = "score_z"
    )
    pl_g2c$time <- factor(
      ifelse(pl_g2c$tname == "pre_score_z", "MS baseline", "MS 12 mo"),
      levels = c("MS baseline", "MS 12 mo")
    )

    n_pt <- nrow(gp)
    n_facet_row <- if (n_pt <= 6L) 2L else if (n_pt <= 10L) 2L else 3L
    n_facet_col <- ceiling(n_pt / n_facet_row)

    p_gse_c2 <- ggplot(pl_g2c, aes(x = time, y = score_z, group = patient_lab)) +
      geom_line(aes(colour = outcome), linewidth = 0.8) +
      geom_point(aes(fill = outcome), size = 2.4, shape = 21, colour = "grey30", stroke = 0.35) +
      facet_wrap(~patient_lab, nrow = n_facet_row, ncol = n_facet_col) +
      scale_colour_manual(values = pal_line_b, name = NULL) +
      scale_fill_manual(values = pal_line_b, name = NULL) +
      labs(
        x = NULL,
        y = expression("Disease-axis score (" * z * ")"),
        title = "(c) Paired treatment trajectories"
      ) +
      theme_fig2a() +
      theme(legend.position = "bottom")

    fig_gse2 <- (p_gse_a | p_gse_b2) / p_gse_c2 + plot_layout(heights = c(0.42, 0.58), widths = c(1, 1))

    tryCatch(
      ggsave(
        file.path(fig, "Fig_GSE235357_disease_axis_and_paired.pdf"),
        fig_gse2, width = 11, height = 9.5, device = grDevices::cairo_pdf
      ),
      error = function(e) {
        ggsave(file.path(fig, "Fig_GSE235357_disease_axis_and_paired.pdf"), fig_gse2, width = 11, height = 9.5)
      }
    )
    ggsave(
      file.path(fig, "Fig_GSE235357_disease_axis_and_paired.png"),
      fig_gse2, width = 11, height = 9.5, dpi = 600, bg = "white"
    )

    # ---- Fig 3 style: PCA + ellipses | latent vectors (same PC1–PC2) ----
    gpca <- gs
    gpca$grp <- gs$grp_plot
    gpca$group <- as.character(gpca$grp)
    ell_g <- pca_ellipse_df(gpca)
    if (!is.null(ell_g)) ell_g$grp <- factor(ell_g$group, levels = levels(gpca$grp))

    p_gse3a <- ggplot()
    if (!is.null(ell_g)) {
      p_gse3a <- p_gse3a + geom_path(
        data = ell_g,
        aes(PC1, PC2, group = piece, colour = grp),
        linewidth = 0.55
      )
    }
    p_gse3a <- p_gse3a +
      geom_point(data = gpca, aes(PC1, PC2, colour = grp), size = 2.3) +
      geom_text(
        data = gpca,
        aes(PC1, PC2, label = sample, colour = grp),
        size = 2.2, vjust = -0.6, show.legend = FALSE
      ) +
      scale_colour_manual(values = pal_three, name = NULL) +
      coord_cartesian(clip = "off") +
      labs(
        title = "(a) PCA of samples (GSE235357)",
        x = sprintf("PC1 (%.2f%%)", pc1_ms),
        y = sprintf("PC2 (%.2f%%)", pc2_ms)
      ) +
      theme_fig2a() +
      theme(legend.position = c(0.02, 0.98), legend.justification = c(0, 1))

    gp$arrow_lab <- ifelse(gp$delta_s_raw < 0, "Toward healthy", "Away / minimal")
    hc_g <- gpca[gpca$grp == "HC", , drop = FALSE]
    ms_g <- gpca[gpca$grp != "HC", , drop = FALSE]

    p_gse3b <- ggplot() +
      geom_point(
        data = hc_g,
        aes(PC1, PC2, fill = grp),
        shape = 21,
        colour = "grey40",
        stroke = 0.25,
        size = 2.7,
        alpha = 0.38
      ) +
      geom_point(
        data = ms_g,
        aes(PC1, PC2, fill = grp),
        shape = 21,
        colour = "grey25",
        stroke = 0.3,
        size = 2.9,
        alpha = 1
      ) +
      scale_fill_manual(values = pal_three, name = NULL) +
      geom_segment(
        data = gp,
        aes(
          x = pre_PC1, y = pre_PC2, xend = post_PC1, yend = post_PC2,
          colour = arrow_lab
        ),
        arrow = grid::arrow(length = grid::unit(0.022, "npc"), type = "closed"),
        linewidth = 0.7
      ) +
      scale_colour_manual(
        values = c("Toward healthy" = col_toward, "Away / minimal" = col_away),
        name = NULL
      ) +
      labs(
        title = "(b) Treatment vectors in latent manifold",
        x = "Latent-1 (PC1)",
        y = "Latent-2 (PC2)"
      ) +
      theme_fig2a() +
      theme(legend.position = c(0.98, 0.02), legend.justification = c(1, 0))

    fig_gse3 <- p_gse3a | p_gse3b

    tryCatch(
      ggsave(
        file.path(fig, "Fig_GSE235357_PCA_and_treatment_vectors.pdf"),
        fig_gse3, width = 12, height = 5.5, device = grDevices::cairo_pdf
      ),
      error = function(e) {
        ggsave(
          file.path(fig, "Fig_GSE235357_PCA_and_treatment_vectors.pdf"),
          fig_gse3, width = 12, height = 5.5
        )
      }
    )
    ggsave(
      file.path(fig, "Fig_GSE235357_PCA_and_treatment_vectors.png"),
      fig_gse3, width = 12, height = 5.5, dpi = 600, bg = "white"
    )

    # ---- Disease axis only (PC1–PC2): HC centroid → MS baseline centroid ----
    mu_h_gse <- colMeans(gs[gs$timepoint == "hc", c("PC1", "PC2"), drop = FALSE])
    mu_b_gse <- colMeans(gs[gs$timepoint == "baseline", c("PC1", "PC2"), drop = FALSE])
    seg_gse <- data.frame(
      x = mu_h_gse[1L], y = mu_h_gse[2L],
      xend = mu_b_gse[1L], yend = mu_b_gse[2L]
    )
    p_dax_gse <- ggplot(gs, aes(PC1, PC2)) +
      geom_point(aes(colour = grp_plot), size = 2.8) +
      scale_colour_manual(values = pal_three, name = NULL) +
      geom_segment(
        data = seg_gse,
        aes(x = x, y = y, xend = xend, yend = yend),
        inherit.aes = FALSE,
        colour = "grey15",
        linewidth = 0.95,
        arrow = grid::arrow(length = grid::unit(0.032, "npc"), type = "closed")
      ) +
      coord_cartesian(clip = "off") +
      labs(
        title = "Disease axis (GSE235357, PBMC)",
        subtitle = "Arrow: HC centroid \u2192 MS baseline (pre-DMF) centroid (PC1\u2013PC2; same orientation as GSE Fig 3)",
        x = sprintf("PC1 (%.2f%%)", pc1_ms),
        y = sprintf("PC2 (%.2f%%)", pc2_ms)
      ) +
      theme_fig2a() +
      theme(legend.position = c(0.02, 0.98), legend.justification = c(0, 1))

    tryCatch(
      ggsave(
        file.path(fig, "Fig_disease_axis_GSE235357.pdf"),
        p_dax_gse, width = 5.8, height = 5, device = grDevices::cairo_pdf
      ),
      error = function(e) ggsave(file.path(fig, "Fig_disease_axis_GSE235357.pdf"), p_dax_gse, width = 5.8, height = 5)
    )
    ggsave(
      file.path(fig, "Fig_disease_axis_GSE235357.png"),
      p_dax_gse, width = 5.8, height = 5, dpi = 600, bg = "white"
    )

    # ---- Compact 3-panel figure (manuscript Fig. 6 style) ----
    gp$col_seg <- ifelse(gp$delta_s_raw < 0, "#00897B", "#C62828")
    pl <- pivot_longer(
      gp[, c("pair_id", "pre_score_z", "post_score_z", "col_seg")],
      cols = c(pre_score_z, post_score_z),
      names_to = "tname",
      values_to = "score_z"
    )
    pl$time <- factor(
      ifelse(pl$tname == "pre_score_z", "Baseline", "12 mo"),
      levels = c("Baseline", "12 mo")
    )

    p_gse_b <- ggplot(pl, aes(x = time, y = score_z, group = pair_id)) +
      geom_line(aes(colour = col_seg), linewidth = 0.85) +
      geom_point(aes(colour = col_seg), size = 2.2) +
      scale_colour_identity(guide = "none") +
      labs(
        x = NULL,
        y = expression("Disease-axis score (" * z * ")"),
        title = expression(paste(
          "(b) Paired baseline / 12 mo (",
          Delta * s < 0,
          ": toward HC)"
        ))
      ) +
      theme_fig2a()

    gs$time_f <- gs$grp_plot
    p_gse_c <- ggplot(gs, aes(PC1, PC2)) +
      geom_point(
        aes(fill = time_f),
        shape = 21, colour = "grey35", stroke = 0.3, size = 2.8, alpha = 0.72
      ) +
      scale_fill_manual(values = pal_v_three, name = NULL) +
      geom_segment(
        data = gp,
        aes(
          x = pre_PC1, y = pre_PC2, xend = post_PC1, yend = post_PC2,
          colour = col_seg
        ),
        inherit.aes = FALSE,
        arrow = grid::arrow(length = grid::unit(0.018, "npc"), type = "closed"),
        linewidth = 0.6
      ) +
      scale_colour_identity(guide = "none") +
      coord_cartesian(
        xlim = range(c(gs$PC1, gp$pre_PC1, gp$post_PC1), na.rm = TRUE),
        ylim = range(c(gs$PC2, gp$pre_PC2, gp$post_PC2), na.rm = TRUE)
      ) +
      labs(
        x = sprintf("PC1 (%.2f%%)", pc1_ms),
        y = sprintf("PC2 (%.2f%%)", pc2_ms),
        title = expression(paste(
          "(c) PC1–PC2; arrows by ",
          Delta * s,
          " (disease axis)"
        ))
      ) +
      pub_theme()

    fig_gse <- (p_gse_a | p_gse_b) / p_gse_c + plot_layout(heights = c(0.42, 0.58), widths = c(1, 1))

    ggsave(file.path(fig, "Fig_GSE235357_framework_replication.pdf"), fig_gse, width = 12, height = 7.35)
    ggsave(
      file.path(fig, "Fig_GSE235357_framework_replication.png"),
      fig_gse, width = 12, height = 7.35, dpi = 600, bg = "white"
    )
  }
}

message("Figures written to ", fig)
