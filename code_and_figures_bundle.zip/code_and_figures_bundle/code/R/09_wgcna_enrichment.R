#!/usr/bin/env Rscript
# Post hoc WGCNA + GO/Reactome on log2(FPKM+1), gene set DISTINCT from PCA top-2000 HVG.
# Run after R/03_disease_axis_from_pca_scores.R (needs results/disease_axis_scores.csv).

rm(list = ls())

ca <- commandArgs(trailingOnly = FALSE)
ff <- grep("^--file=", ca, value = TRUE)
rdir <- if (length(ff)) dirname(normalizePath(sub("^--file=", "", ff[1]))) else normalizePath(file.path(getwd(), "R"))
source(file.path(rdir, "ldaf_common.R"))

expr_path <- proj_path("results", "01_expr_filtered.csv")
score_path <- proj_path("results", "disease_axis_scores.csv")
out_dir <- proj_path("results", "wgcna")
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

req <- c("WGCNA", "clusterProfiler", "org.Hs.eg.db", "ReactomePA", "enrichplot", "ggplot2")
miss <- req[!vapply(req, requireNamespace, logical(1), quietly = TRUE)]
if (length(miss)) {
  stop(
    "缺少包: ", paste(miss, collapse = ", "),
    "\n安装: BiocManager::install(c(\"WGCNA\",\"clusterProfiler\",\"org.Hs.eg.db\",\"ReactomePA\",\"enrichplot\")); install.packages(\"ggplot2\")"
  )
}
# Load ONLY WGCNA first: clusterProfiler/BiocGenerics attach generics that break
# WGCNA::blockwiseModules internal cor/do.call on R 4.5+.
library(WGCNA)

options(stringsAsFactors = FALSE)
disableWGCNAThreads()

meta_cols <- c("gene_id", "gene_name", "gene_locus")
expr_tbl <- read.csv(expr_path, check.names = FALSE, stringsAsFactors = FALSE)
sample_cols <- setdiff(names(expr_tbl), meta_cols)
fpkm_mat <- as.matrix(expr_tbl[, sample_cols, drop = FALSE])
storage.mode(fpkm_mat) <- "double"

# samples x genes on log2(FPKM+1)
log_mat <- t(log2(fpkm_mat + 1))
sample_names <- rownames(log_mat)
colnames(log_mat) <- as.character(expr_tbl$gene_id)

datExpr0 <- as.data.frame(log_mat)

# QC: remove genes/samples with excessive missingness (none expected) and zero-variance genes
gsg <- goodSamplesGenes(datExpr0, verbose = 3)
if (!gsg$allOK) {
  datExpr0 <- datExpr0[gsg$goodSamples, gsg$goodGenes, drop = FALSE]
}

# WGCNA-specific filter (NOT the PCA 2000 HVG): expression + variance
gene_mean <- colMeans(datExpr0, na.rm = TRUE)
gene_var <- apply(datExpr0, 2, stats::var)
keep <- gene_var > 1e-8 & gene_mean >= stats::quantile(gene_mean, 0.15)
datExpr0 <- datExpr0[, keep, drop = FALSE]

# Cap gene count for stability / speed (rank by variance on log scale)
nv <- ncol(datExpr0)
max_genes <- 10000L
if (nv > max_genes) {
  ord <- order(apply(datExpr0, 2, stats::var), decreasing = TRUE)
  datExpr0 <- datExpr0[, ord[seq_len(max_genes)], drop = FALSE]
}

datExpr <- datExpr0

# Signed network soft threshold
powers <- c(1:20)
sft <- pickSoftThreshold(
  datExpr,
  powerVector = powers,
  networkType = "signed",
  verbose = 0
)

# Soft threshold: beta=1–3 often yields a near-complete signed graph -> one huge module + heavy kME pruning.
# Prefer medium beta with acceptable scale-free fit; never pick beta<6 in the fallback path.
sft_tab <- sft$fitIndices
cand85 <- sft_tab$Power[sft_tab$Power >= 6 & sft_tab$SFT.R.sq >= 0.85]
cand72 <- sft_tab$Power[sft_tab$Power >= 6 & sft_tab$SFT.R.sq >= 0.72]
softPower <- if (length(cand85)) {
  min(cand85)
} else if (length(cand72)) {
  min(cand72)
} else {
  sub <- sft_tab[sft_tab$Power >= 8 & sft_tab$Power <= 20, ]
  as.integer(sub$Power[which.max(sub$SFT.R.sq)])
}
softPower <- as.integer(softPower)

pdf(file.path(out_dir, "wgcna_soft_threshold.pdf"), width = 7, height = 3.5)
par(mfrow = c(1, 2))
plot(sft_tab[, 1], sft_tab[, 2], xlab = "Power", ylab = "Scale free topology model fit, signed R^2", type = "n")
text(sft_tab[, 1], sft_tab[, 2], labels = powers, cex = 0.85, col = "red")
abline(h = 0.85, col = "red")
plot(sft_tab[, 1], sft_tab[, 5], xlab = "Power", ylab = "Mean connectivity", type = "n")
text(sft_tab[, 1], sft_tab[, 5], labels = powers, cex = 0.85, col = "red")
dev.off()

net <- blockwiseModules(
  datExpr,
  power = softPower,
  networkType = "signed",
  TOMType = "signed",
  minModuleSize = 20,
  reassignThreshold = 0,
  mergeCutHeight = 0.15,
  deepSplit = 4,
  pamRespectsDendro = TRUE,
  numericLabels = TRUE,
  saveTOMs = FALSE,
  verbose = 3,
  maxBlockSize = ncol(datExpr)
)

module_labels <- net$colors
module_colors <- labels2colors(module_labels)
MEs0 <- moduleEigengenes(datExpr, colors = module_labels)$eigengenes
MEs <- orderMEs(MEs0)

score_df <- read.csv(score_path, check.names = FALSE, stringsAsFactors = FALSE)
score_df <- score_df[match(rownames(datExpr), score_df$sample), , drop = FALSE]
if (anyNA(score_df$sample)) stop("disease_axis_scores.csv 与表达矩阵样本名不一致。")

trait <- data.frame(disease_axis_score = score_df$score_raw)
rownames(trait) <- score_df$sample

moduleTraitCor <- stats::cor(MEs, trait$disease_axis_score, use = "pairwise.complete.obs")
moduleTraitP <- WGCNA::corPvalueStudent(moduleTraitCor, nSamples = nrow(datExpr))

mod_cor_tbl <- data.frame(
  module = colnames(MEs),
  cor_score = as.numeric(moduleTraitCor),
  p_value = as.numeric(moduleTraitP),
  stringsAsFactors = FALSE
)
mod_cor_tbl <- mod_cor_tbl[order(-abs(mod_cor_tbl$cor_score)), ]

write.csv(
  data.frame(gene_id = colnames(datExpr), module = module_labels, color = module_colors, stringsAsFactors = FALSE),
  file.path(out_dir, "module_gene_assignment.csv"),
  row.names = FALSE
)
write.csv(mod_cor_tbl, file.path(out_dir, "module_trait_correlation.csv"), row.names = FALSE)

# Heatmap ME vs trait
pdf(file.path(out_dir, "module_trait_heatmap.pdf"), width = 4, height = 8)
textMatrix <- paste(signif(moduleTraitCor, 2), "\n(", signif(moduleTraitP, 1), ")", sep = "")
dim(textMatrix) <- dim(moduleTraitCor)
par(mar = c(6, 8, 2, 2))
labeledHeatmap(
  Matrix = moduleTraitCor,
  xLabels = "Disease axis score",
  yLabels = colnames(MEs),
  ySymbols = colnames(MEs),
  colorLabels = FALSE,
  colors = blueWhiteRed(50),
  textMatrix = textMatrix,
  setStdMargins = FALSE,
  cex.text = 0.45,
  zlim = c(-1, 1),
  main = paste("Module–trait relationships (signed, power=", softPower, ")", sep = "")
)
dev.off()

# --- Enrichment: 双模块叙事（负相关 + 正相关各一；GO 在 WGCNA universe 下须可检出）---
suppressPackageStartupMessages({
  library(clusterProfiler)
  library(org.Hs.eg.db)
  library(ReactomePA)
  library(enrichplot)
  library(ggplot2)
})

param_lines <- c(
  paste0("softPower=", softPower),
  paste0("nSamples=", nrow(datExpr)),
  paste0("nGenesWGCNA=", ncol(datExpr)),
  "networkType=signed; TOM=signed; minModuleSize=20; mergeCutHeight=0.15; deepSplit=4; pamRespectsDendro=TRUE",
  "gene filter: var>0 & mean>=15pct quantile; cap 10000 genes by variance (NOT PCA HVG)"
)
writeLines(param_lines, file.path(out_dir, "wgcna_parameters.txt"))

universe <- colnames(datExpr)

me_k_from_name <- function(me) as.integer(sub("^ME", "", me))
gene_count_for_me <- function(me_name) {
  k <- me_k_from_name(me_name)
  if (is.na(k)) return(0L)
  sum(module_labels == k)
}

mod_rank <- mod_cor_tbl[mod_cor_tbl$module != "ME0", , drop = FALSE]
mod_rank$n_genes <- vapply(mod_rank$module, gene_count_for_me, integer(1))
min_mod_genes <- 50L
mod_ok <- mod_rank[mod_rank$n_genes >= min_mod_genes, , drop = FALSE]

neg <- mod_ok[mod_ok$cor_score < 0, , drop = FALSE]
neg <- neg[order(neg$cor_score), ]
pos <- mod_ok[mod_ok$cor_score > 0, , drop = FALSE]
pos <- pos[order(-pos$cor_score), ]

go_bp_has_hits <- function(me_name) {
  k <- me_k_from_name(me_name)
  if (is.na(k)) return(FALSE)
  genes_mod <- colnames(datExpr)[module_labels == k]
  if (length(genes_mod) < 10L) return(FALSE)
  ego <- tryCatch(
    enrichGO(
      gene = genes_mod,
      OrgDb = org.Hs.eg.db,
      keyType = "ENSEMBL",
      ont = "BP",
      universe = universe,
      pAdjustMethod = "BH",
      pvalueCutoff = 0.05,
      qvalueCutoff = 0.2
    ),
    error = function(e) NULL
  )
  !is.null(ego) && nrow(as.data.frame(ego)) > 0L
}

neg_pick <- NA_character_
for (nm in neg$module) {
  if (go_bp_has_hits(nm)) {
    neg_pick <- nm
    break
  }
}
if (is.na(neg_pick) && nrow(neg) > 0) neg_pick <- neg$module[1]

pos_pick <- NA_character_
for (nm in pos$module) {
  if (go_bp_has_hits(nm)) {
    pos_pick <- nm
    break
  }
}
if (is.na(pos_pick) && nrow(pos) > 0) pos_pick <- pos$module[1]

sel <- unique(c(neg_pick, pos_pick))
sel <- sel[!is.na(sel) & nzchar(sel)]
if (length(sel) < 2L) {
  mod_ok2 <- mod_ok[order(-abs(mod_ok$cor_score)), , drop = FALSE]
  sel <- unique(c(sel, head(mod_ok2$module, 2L)))
  sel <- head(sel, 2L)
}
if (length(sel) > 2L) sel <- sel[seq_len(2L)]

writeLines(sel, file.path(out_dir, "enrichment_modules_selected.txt"))

# 去掉旧富集结果，避免更换模块编号后残留 ME61 等文件
for (f in list.files(out_dir, pattern = "^GO_BP_ME.*\\.(csv|pdf)$", full.names = TRUE)) unlink(f)
for (f in list.files(out_dir, pattern = "^Reactome_ME.*\\.(csv|pdf)$", full.names = TRUE)) unlink(f)

enrich_one <- function(me_name) {
  k <- as.integer(sub("^ME", "", me_name))
  if (is.na(k)) return(invisible(NULL))
  genes_mod <- colnames(datExpr)[module_labels == k]
  if (length(genes_mod) < 10L) return(invisible(NULL))
  ego <- tryCatch(
    enrichGO(
      gene = genes_mod,
      OrgDb = org.Hs.eg.db,
      keyType = "ENSEMBL",
      ont = "BP",
      universe = universe,
      pAdjustMethod = "BH",
      pvalueCutoff = 0.05,
      qvalueCutoff = 0.2,
      readable = TRUE
    ),
    error = function(e) NULL
  )
  if (!is.null(ego) && nrow(as.data.frame(ego)) > 0L) {
    write.csv(as.data.frame(ego), file.path(out_dir, paste0("GO_BP_", me_name, ".csv")), row.names = FALSE)
    p <- dotplot(ego, showCategory = 12) + ggtitle(paste("GO BP", me_name))
    ggsave(file.path(out_dir, paste0("GO_BP_", me_name, ".pdf")), p, width = 7, height = 5.5)
  }
  eg_sym <- tryCatch(
    bitr(genes_mod, fromType = "ENSEMBL", toType = "ENTREZID", OrgDb = org.Hs.eg.db),
    error = function(e) NULL
  )
  if (!is.null(eg_sym) && nrow(eg_sym) > 0L) {
    u_map <- tryCatch(
      bitr(universe, fromType = "ENSEMBL", toType = "ENTREZID", OrgDb = org.Hs.eg.db),
      error = function(e) NULL
    )
    u_ez <- if (!is.null(u_map) && nrow(u_map) > 0L) unique(u_map$ENTREZID) else NULL
    rpa <- tryCatch(
      enrichPathway(
        gene = eg_sym$ENTREZID,
        organism = "human",
        pAdjustMethod = "BH",
        pvalueCutoff = 0.05,
        qvalueCutoff = 0.2,
        universe = u_ez
      ),
      error = function(e) NULL
    )
    if (!is.null(rpa) && nrow(as.data.frame(rpa)) > 0L) {
      write.csv(as.data.frame(rpa), file.path(out_dir, paste0("Reactome_", me_name, ".csv")), row.names = FALSE)
      p2 <- dotplot(rpa, showCategory = 12) + ggtitle(paste("Reactome", me_name))
      ggsave(file.path(out_dir, paste0("Reactome_", me_name, ".pdf")), p2, width = 7, height = 5.5)
    }
  }
}

for (me in sel) enrich_one(me)

sink(file.path(out_dir, "sessionInfo.txt"))
print(sessionInfo())
sink()

message("WGCNA 输出目录: ", out_dir)
