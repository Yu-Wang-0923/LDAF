rm(list = ls())

ca <- commandArgs(trailingOnly = FALSE)
ff <- grep("^--file=", ca, value = TRUE)
rdir <- if (length(ff)) dirname(normalizePath(sub("^--file=", "", ff[1]))) else normalizePath(file.path(getwd(), "R"))
source(file.path(rdir, "ldaf_common.R"))

input_csv <- proj_path("results", "01_expr_filtered.csv")
output_dir <- proj_path("results", "higher_k_sensitivity")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

n_hvg <- 2000L

# 固定k + 累计解释率阈值
fixed_k_list <- c(2, 3, 5)
cumvar_thresholds <- c(0.60, 0.80)

expr_tbl <- read.csv(input_csv, check.names = FALSE, stringsAsFactors = FALSE)
prep <- prepare_fpkm_and_z_log2(expr_tbl)
Z_log2 <- prep$Z_log2
sample_names <- prep$sample_names
sample_group <- prep$sample_group

id_tbl <- append_prefix_id(data.frame(sample = sample_names, stringsAsFactors = FALSE))
sample_prefix <- id_tbl$prefix
sample_id_num <- id_tbl$id_num

ph <- pca_top_hvg(Z_log2, n_hvg)
pca_result <- ph$pca_result
var_prop <- summary(pca_result)$importance[2, ]
cum_prop <- summary(pca_result)$importance[3, ]

#========================
# 3. 确定要分析的k集合
#========================
threshold_k <- sapply(cumvar_thresholds, function(thr) {
  k <- which(cum_prop >= thr)[1]
  if (is.na(k)) k <- length(cum_prop)
  k
})

k_tbl <- data.frame(
  source = c(paste0("fixed_k_", fixed_k_list),
             paste0("cumvar_", cumvar_thresholds * 100, "pct")),
  k = c(fixed_k_list, threshold_k),
  stringsAsFactors = FALSE
)

# 去重并按k排序
k_tbl <- unique(k_tbl)
k_tbl <- k_tbl[order(k_tbl$k), ]

write.csv(
  k_tbl,
  file.path(output_dir, "higher_k_settings.csv"),
  row.names = FALSE
)

#========================
# 4. 定义一个函数：在给定k下做 disease-axis 分析
#========================
run_k_analysis <- function(k, label) {

  # 取前k个PC
  Yk <- pca_result$x[, seq_len(k), drop = FALSE]
  colnames(Yk) <- paste0("PC", seq_len(k))

  scores_tbl <- data.frame(
    sample = sample_names,
    group = sample_group,
    prefix = sample_prefix,
    id_num = sample_id_num,
    Yk,
    stringsAsFactors = FALSE
  )

  pc_cols <- paste0("PC", seq_len(k))

  # centroid in k-dimensional PC space
  mu_HC <- colMeans(scores_tbl[scores_tbl$group == "HC", pc_cols, drop = FALSE])
  mu_SLE <- colMeans(scores_tbl[scores_tbl$group == "SLE", pc_cols, drop = FALSE])

  v_raw <- mu_SLE - mu_HC
  v <- v_raw / sqrt(sum(v_raw^2))

  # HC-centered score
  Ymat <- as.matrix(scores_tbl[, pc_cols, drop = FALSE])
  Y_centered <- sweep(Ymat, 2, mu_HC, FUN = "-")
  score_raw <- as.numeric(Y_centered %*% v)
  score_z <- as.numeric(scale(score_raw))

  scores_tbl$score_raw <- score_raw
  scores_tbl$score_z <- score_z
  scores_tbl$k_used <- k
  scores_tbl$k_label <- label

  # 组均值
  group_mean <- tapply(scores_tbl$score_raw, scores_tbl$group, mean)
  mean_HC   <- unname(group_mean["HC"])
  mean_SLE  <- unname(group_mean["SLE"])
  mean_SLET <- unname(group_mean["SLET"])

  ordering_ok <- isTRUE(mean_HC < mean_SLET && mean_SLET < mean_SLE)

  # paired Δs
  pre_df  <- scores_tbl[scores_tbl$prefix == "D", c("sample", "group", pc_cols, "score_raw", "score_z", "id_num")]
  post_df <- scores_tbl[scores_tbl$prefix == "B", c("sample", "group", pc_cols, "score_raw", "score_z", "id_num")]

  names(pre_df)[1:2] <- c("pre_sample", "pre_group")
  names(post_df)[1:2] <- c("post_sample", "post_group")

  names(pre_df)[(ncol(pre_df)-2):ncol(pre_df)] <- c("pre_score_raw", "pre_score_z", "id_num")
  names(post_df)[(ncol(post_df)-2):ncol(post_df)] <- c("post_score_raw", "post_score_z", "id_num")

  pair_tbl <- merge(pre_df, post_df, by = "id_num", all = FALSE)
  pair_tbl <- pair_tbl[order(as.numeric(pair_tbl$id_num)), ]

  pair_tbl$delta_s_raw <- pair_tbl$post_score_raw - pair_tbl$pre_score_raw
  pair_tbl$delta_s_z   <- pair_tbl$post_score_z   - pair_tbl$pre_score_z
  pair_tbl$pair_id <- paste0("Pair_", pair_tbl$id_num)
  pair_tbl$direction_label <- ifelse(pair_tbl$delta_s_raw < 0,
                                     "toward_health",
                                     "non_improving_or_opposite")
  pair_tbl$k_used <- k
  pair_tbl$k_label <- label

  # 可选：在k维空间中算 vector length / cos(theta)
  pre_pc_cols  <- grep("^PC\\d+$", names(pre_df), value = TRUE)
  post_pc_cols <- grep("^PC\\d+$", names(post_df), value = TRUE)

  # merge后 pre/post维度列名会保留原名，不能直接用，所以手动找
  pre_cols_merged  <- paste0("PC", seq_len(k), ".x")
  post_cols_merged <- paste0("PC", seq_len(k), ".y")

  if (all(pre_cols_merged %in% names(pair_tbl)) && all(post_cols_merged %in% names(pair_tbl))) {
    delta_mat <- as.matrix(pair_tbl[, post_cols_merged, drop = FALSE]) -
      as.matrix(pair_tbl[, pre_cols_merged, drop = FALSE])

    pair_tbl$vector_length <- sqrt(rowSums(delta_mat^2))
    pair_tbl$cos_theta <- as.numeric(delta_mat %*% v) / pair_tbl$vector_length
    pair_tbl$cos_theta[!is.finite(pair_tbl$cos_theta)] <- NA
  } else {
    pair_tbl$vector_length <- NA_real_
    pair_tbl$cos_theta <- NA_real_
  }

  # 汇总
  summary_row <- data.frame(
    k_label = label,
    k_used = k,
    cumulative_variance_pct = round(100 * cum_prop[k], 2),
    mean_score_HC = mean_HC,
    mean_score_SLET = mean_SLET,
    mean_score_SLE = mean_SLE,
    ordering_HC_lt_SLET_lt_SLE = ordering_ok,
    n_pairs = nrow(pair_tbl),
    n_toward_health = sum(pair_tbl$delta_s_raw < 0, na.rm = TRUE),
    prop_toward_health = round(sum(pair_tbl$delta_s_raw < 0, na.rm = TRUE) / nrow(pair_tbl), 3),
    stringsAsFactors = FALSE
  )

  list(
    summary_row = summary_row,
    scores_tbl = scores_tbl,
    pair_tbl = pair_tbl,
    v = v
  )
}

#========================
# 5. 逐个k运行
#========================
summary_list <- list()
pair_list <- list()

for (i in seq_len(nrow(k_tbl))) {
  this_k <- k_tbl$k[i]
  this_label <- k_tbl$source[i]

  res <- run_k_analysis(this_k, this_label)

  summary_list[[this_label]] <- res$summary_row
  pair_list[[this_label]] <- res$pair_tbl[, c(
    "k_label", "k_used", "pair_id",
    "pre_sample", "post_sample",
    "delta_s_raw", "delta_s_z",
    "vector_length", "cos_theta", "direction_label"
  )]

  write.csv(
    res$scores_tbl,
    file.path(output_dir, paste0("disease_axis_scores_", this_label, ".csv")),
    row.names = FALSE
  )

  write.csv(
    res$pair_tbl,
    file.path(output_dir, paste0("paired_response_", this_label, ".csv")),
    row.names = FALSE
  )
}

higher_k_summary <- do.call(rbind, summary_list)
higher_k_pairs <- do.call(rbind, pair_list)

write.csv(
  higher_k_summary,
  file.path(output_dir, "higher_k_sensitivity_summary.csv"),
  row.names = FALSE
)

write.csv(
  higher_k_pairs,
  file.path(output_dir, "higher_k_sensitivity_pairs.csv"),
  row.names = FALSE
)

#========================
# 6. 顺手导出 PCA 前10个PC解释率
#========================
pca_var_tbl <- data.frame(
  PC = paste0("PC", seq_along(var_prop)),
  variance_explained = as.numeric(var_prop),
  cumulative_variance = as.numeric(cum_prop),
  variance_explained_pct = round(100 * as.numeric(var_prop), 2),
  cumulative_variance_pct = round(100 * as.numeric(cum_prop), 2),
  stringsAsFactors = FALSE
)

write.csv(
  head(pca_var_tbl, 10),
  file.path(output_dir, "pca_variance_pc1_pc10_reference.csv"),
  row.names = FALSE
)

#========================
# 7. 控制台输出
#========================
cat("\n=== higher-k sensitivity summary ===\n")
print(higher_k_summary, row.names = FALSE)

message("\n已写入目录：", output_dir)
message("主要文件：")
message("1) higher_k_settings.csv")
message("2) higher_k_sensitivity_summary.csv")
message("3) higher_k_sensitivity_pairs.csv")
message("4) pca_variance_pc1_pc10_reference.csv")
message("以及每个k配置下的明细结果文件")